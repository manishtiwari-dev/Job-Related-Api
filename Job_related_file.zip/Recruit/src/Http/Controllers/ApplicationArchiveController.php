<?php


namespace Modules\Recruit\Http\Controllers;

use Modules\Recruit\Exports\JobApplicationArchiveExport;
use App\Helper\Reply;
use Modules\Recruit\Models\JobApplication;
use Modules\Recruit\Models\JobApplicationAnswer;
use Modules\Recruit\Models\Skill;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Excel as ExcelExcel;
use Maatwebsite\Excel\Facades\Excel;
use Yajra\DataTables\Facades\DataTables;
use App\Http\Controllers\Controller;
use ApiHelper;


class ApplicationArchiveController extends Controller
{
    

    public $page = 'candidate_database';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pageremove = 'remove';
    public $pageupdate = 'update'; 

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
         $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');
    
        $jobApplications = JobApplication::onlyTrashed();

        $res = [ 
        ];
       return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function data(Request $request)
    { 

        $jobApplications = JobApplication::with('job','job.location')->onlyTrashed();

        // Filter by skills
            if ($request->has('skill') && $request->skill !== null) {
                
                $skill = Skill::select('id', 'name')->where('name', 'LIKE', '%'.strtolower($request->skill).'%')->first();

                if ($skill) {
                    $jobApplications = $jobApplications->whereJsonContains('skills', (string) $skill->id)->get();
                }
                else {
                    $jobApplications = collect([]);
                }
            }
            else {
                $jobApplications = $jobApplications->get();
            }
 
        $res = [

                'jobApplications' => $jobApplications, 
            ];



        return ApiHelper::JSON_RESPONSE(true, $res, ''); 
    }

    public function destroy(Request $request)
    {
         $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageremove))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        $jobApplication = JobApplication::findOrFail($request->id);

        if ($jobApplication->photo) {
            Storage::delete('candidate-photos/'.$jobApplication->photo);
        }

        $jobApplication->delete();

         return ApiHelper::JSON_RESPONSE(true, $jobApplication, 'DELETED_SUCCESS'); 
    }

    public function show(Request $request)
    {

        $application = JobApplication::with(['schedule','onboard', 'status', 'schedule.employee', 'schedule.comments.user'])->withTrashed()->find($request->id);


        $skills = Skill::select('id', 'name')->get();

        $answers = JobApplicationAnswer::with(['question'])
            ->where('job_id', $application->job_id)
            ->where('job_application_id', $application->id)
            ->get();

        $res = [
            'application' => $application,
            'skills' => $skills,
            'answers' => $answers,
        ];



         return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function export(Request $request)
    {
        $filters = [
            'skill' => $request->skill,
        ];

        

        $data = Excel::store(new JobApplicationArchiveExport($filters), 'candidate-database'.'.xlsx');

        $url = Storage::path('candidate-database'.'.xlsx');

        return ApiHelper::JSON_RESPONSE(true,$url,'');

    }
    
    public function deleteRecords(Request $request){
     
            JobApplication::whereIn('id', explode(',',$request->id))->forceDelete();
            
           return ApiHelper::JSON_RESPONSE(true,[],'RECORD_DELETED_SUCCESS');
        }
}
