<?php

namespace Modules\Recruit\Http\Controllers;


use Modules\Recruit\Models\JobType;
use Modules\Recruit\Models\Department;
use Modules\Recruit\Models\Helper\Reply;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use ApiHelper;
use App\Helper\Helper;


class JobTypeController extends Controller
{
   

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //
    }

    public function create()
    { 

        $jobTypes = JobType::all();

         $res = [
            'jobTypes' => $jobTypes, 
        ];

          return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function edit($id)
    {
       //
    }

    public function store(Request $request)
    {

        $data = new JobType;
        $data->job_type = $request->job_type;
        $data->save();

        $data = JobType::all();

         if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_ADD_JOB_TYPE'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_JOB_TYPE_ADD');
        }
    }

    public function update(Request $request)
    {
        $data = JobType::findOrFail($request->id);
        $data->job_type = $request->job_type;
        $data->save();

        $data = JobType::all();

         if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_UPDATE_JOB_TYPE'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_JOB_TYPE_UPDATE');
        }
    }

    public function destroy(Request $request)
    {
        JobType::destroy($request->id);

        $data = JobType::all();

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_DELETE_JOB_TYPE'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_JOB_TYPE_DELETE');
        }

       
    }

    public function show($id)
    {
        //
    }
}
