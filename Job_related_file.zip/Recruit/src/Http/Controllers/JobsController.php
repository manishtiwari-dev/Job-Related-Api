<?php

namespace Modules\Recruit\Http\Controllers;

use Modules\Recruit\Models\Job;
use Modules\Recruit\Models\Skill;
use Modules\Recruit\Models\JobType;
use Modules\Recruit\Models\JobSkill;
use Modules\Recruit\Models\JobCategory;
use Modules\Recruit\Models\JobLocation;
use Modules\Recruit\Models\JobApplication;
use Modules\Recruit\Models\Question;
use Modules\Recruit\Models\WorkExperience;
use Modules\Recruit\Models\ApplicationStatus;
use ApiHelper;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Events\JobAlertEvent;
use App\Http\Requests\StoreJob;
use App\Http\Requests\UpdateJob;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Jobs\NewJobMail;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Notification;
use Carbon\Carbon; 

class JobsController extends Controller
{

    
    public $page = 'jobs';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pageremove = 'remove';
    public $pageupdate = 'update';

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index(Request $request)
    {
        
        $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        $totalJobs = Job::count();
        $locations = JobLocation::all();
        $jobs = Job::with('location')->orderBy("sort_order", "asc")->get();
        $activeJobs = Job::where('status', 'active')->count();
        $inactiveJobs = Job::where('status', 'inactive')->count();

        $res = [
            'totalJobs' => $totalJobs,
            'locations' => $locations,
            'activeJobs' => $activeJobs,
            'inactiveJobs' => $inactiveJobs,
            'jobs'=>$jobs
        ];

          return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {

        $job = ($request->duplicate_job ? Job::with(['category', 'skills', 'questions'])->findOrFail($request->duplicate_job) : null);
        
         $skills = '';

        if (!is_null($job)) {
             $jobQuestion = $job->questions->pluck('id')->toArray();

            $skills = Skill::where('category_id', $job->category_id)->get();
        }



        $categories = JobCategory::all();
        $locations = JobLocation::all();
        $jobTypes = JobType::all(); 
        $questions = Question::all(); 
        $workExperiences = WorkExperience::all();



        $res = [
            'categories' => $categories,
            'locations' =>$locations,
            'jobTypes' => $jobTypes,
            'job' => $job,
            'questions' => $questions,
            'skills' => $skills,
            'workExperiences' => $workExperiences

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, ''); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {  
        $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

      
        $job = new Job();
        $job->slug = Str::slug($request->title);
        $job->company_id = $request->company;
        $job->title = $request->title;
        $job->job_description = $request->job_description;
        $job->job_requirement = $request->job_requirement;
        $job->total_positions = $request->total_positions;
        $job->location_id = $request->location_id;
        $job->category_id = $request->category_id;
        $job->start_date = Carbon::createFromFormat('d/m/Y', $request->start_date)->format(' Y-m-d');
        $job->end_date = Carbon::createFromFormat('d/m/Y', $request->end_date)->format(' Y-m-d');
        $job->status = $request->status;
        $job->job_type_id = $request->job_type_id;
        $job->work_experience_id = $request->work_experience_id;
        $job->pay_type = $request->pay_type;
        $job->pay_according = $request->pay_according;
        $job->sort_order = $request->sort_order;
        $job->starting_salary = $request->starting_salary;
        $job->maximum_salary = $request->maximum_salary;
        $job->required_columns = $request->required_columns;
        $job->section_visibility = $request->section_visibility;
        $job->details_visibility = $request->details_visibility;
        $job->meta_details = [
            'title' => $request->meta_title ?: $request->title,
            'description' => $request->meta_description ?: strip_tags(Str::substr(html_entity_decode($request->job_description), 0, 150))
        ];

      

        $jobData = $job->save();

        if (!is_null($request->skill_id)) {
            JobSkill::where('job_id', $job->id)->delete();

            foreach ($request->skill_id as $skill) {
                $jobSkill = new JobSkill();
                $jobSkill->skill_id = $skill;
                $jobSkill->job_id = $job->id;
                $jobSkill->save();
            }
        }

        //   $job->questions()->sync($request->question);
        // event(new JobAlertEvent($job));
 
 
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_ADD_SKILLS'); 
         
    }

   

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit( Request $request)
    { 

        $job = Job::with('skills')->find($request->id);
        $categories = JobCategory::all();
        $locations = JobLocation::with('country')->get();
        $skills = Skill::where('category_id', $job->category_id)->get();
        $jobQuestion = $job->questions->pluck('id')->toArray();
        $questions = Question::all(); 
        $jobTypes = JobType::all(); 
        $workExperiences = WorkExperience::all();

          $res = [
            'job'=>$job, 
            'categories' => $categories,
            'locations' => $locations,
            'skills' => $skills,
            'jobQuestion' => $jobQuestion,
            'questions' => $questions,
            'jobTypes' => $jobTypes, 
            'workExperiences' => $workExperiences
            
        ];
 

        return ApiHelper::JSON_RESPONSE(true, $res, ''); 
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {  
        $api_token = $request->api_token; 

        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');
    
        

        if(!empty($request->slug)){
            $slug = $request->slug;
        }else{
            $slug = Str::slug($request->title);
        }

        $job = Job::find($request->id);
        $job->slug = $slug;
        $job->title = $request->title;
        $job->job_description = $request->job_description;
        $job->job_requirement = $request->job_requirement;
        $job->total_positions = $request->total_positions;
        $job->location_id = $request->location_id;
        $job->category_id = $request->category_id;
        $job->start_date = Carbon::createFromFormat('d/m/Y', $request->start_date)->format(' Y-m-d');
        $job->end_date = Carbon::createFromFormat('d/m/Y', $request->end_date)->format(' Y-m-d');;
        $job->status = $request->status;
        $job->job_type_id = $request->job_type_id;
        $job->work_experience_id = $request->work_experience_id;
        $job->pay_type = $request->pay_type;
        $job->pay_according = $request->pay_according;
        $job->sort_order = $request->sort_order;
        $job->starting_salary = $request->starting_salary;
        $job->maximum_salary = $request->maximum_salary;
        $job->required_columns = $request->required_columns;
        $job->section_visibility = $request->section_visibility;
        $job->details_visibility = $request->details_visibility;
        $job->meta_details = [
            'title' => $request->meta_title ?: $job->title,
            'description' => $request->meta_description ?: strip_tags(Str::substr(html_entity_decode($job->job_description), 0, 150))
        ];

        
        $job->save();

        if (!is_null($request->skill_id)) {
            JobSkill::where('job_id', $job->id)->delete();

            foreach ($request->skill_id as $skill) {
                $jobSkill = new JobSkill();
                $jobSkill->skill_id = $skill;
                $jobSkill->job_id = $job->id;
                $jobSkill->save();
            }
        }  

         $job->questions()->sync($request->question);

         return ApiHelper::JSON_RESPONSE(true, [], 'UPDATE_ADD_SKILLS'); 
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        
        
        $api_token = $request->api_token; 
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageremove))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');


         $data =Job::destroy($request->id); 

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_DELETE_JOBS'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_JOBS_DELETE');
        }


    }

    public function data(Request $request)
    { 

        $categories = Job::with('location')->where('id', '>', '0')->orderBy("sort_order", "asc");

        if ($request->filter_company != "") {
            $categories->where('company_id', $request->filter_company );
        }

        if ($request->filter_status != "") {
            $categories->where('status', $request->filter_status);
        }
        if ($request->filter_location != "") {
            $categories->where('location_id', $request->filter_location);
        }

        $categories = $categories->get();

        $res = [

                'categories' => $categories, 
            ];



        return ApiHelper::JSON_RESPONSE(true, $res, ''); 
     
    }

    public function sendEmail(Request $request)
    {

        $boardColumns = ApplicationStatus::where('status', '!=', 'hired')->get(); 
        $locations = JobLocation::all();
        $jobs = Job::all();
        $skills = Skill::all();

         $res = [

                'boardColumns' => $boardColumns, 
                'locations' => $locations, 
                'jobs' => $jobs, 
                'skills' => $skills, 
            ];


        return ApiHelper::JSON_RESPONSE(true, $res, ''); 
    }

    public function sendEmails(Request $request)
    {

        // Please select job for which the emails will be sent
        if ($request->allSelected == 'false') {
            if (!$request->has('selectedIds')) {
                return ApiHelper::JSON_RESPONSE(true, [], 'Please select applicants before sending emails.'); 
            }

            $jobApplications = JobApplication::whereIn('id', $request->selectedIds)->with('jobs');
        } else {

            $jobApplications = JobApplication::with('jobs');
        }
        // dd($request->job_for_email);

        // get jobApplication
        $job = Job::findOrFail($request->job_for_email);


        if ($request->excludeSent == 'true') {
            $jobApplicationsCopy = clone $jobApplications;


            $jobApplicationIds = $jobApplicationsCopy->whereHas('jobs', function ($q) use ($request) {
                $q->where('job_id', $request->job_for_email);
            })->get()->map(function ($jobApplication) {
                return $jobApplication->id;
            })->toArray();

            $jobApplications = $jobApplications->whereNotIn('rec_job_applications.id', $jobApplicationIds);
        }

        $jobApplications = $jobApplications->get();

        $jobApplicationIds = $jobApplications->map(function ($jobApplication) {
            return $jobApplication->id;
        })->toArray();

        $job->applications()->syncWithoutDetaching($jobApplicationIds);

        $uniqueEmailJobs = $jobApplications->unique(function ($job) {
            return $job['email'];
        });


        if ($jobApplications->count() > 0) { 

            $details = [
                'email' => $uniqueEmailJobs,
                'message' => $job,
            ];
            
            NewJobMail::dispatch($details);

        }
 
        return ApiHelper::JSON_RESPONSE(true, [], 'EMAIL_SEND_SUCCESSFULLY'); 
    }


    public function filterJobApplications(Request $request)
    {

        $job_applications = config('dbtable.rec_job_applications'); 
        $jobs =config('dbtable.rec_jobs');  
        $application_status =config('dbtable.rec_application_status'); 
        $rec_job_skills =config('dbtable.rec_job_skills'); 
        $rec_job_locations =config('dbtable.rec_job_locations');
 

        $jobApplicationRec = JobApplication::select($job_applications.'.id as application')->with('jobs')
            ->where(''.$job_applications.'.status_id', '!=', ApplicationStatus::where('status', 'hired')->first()->id)
            ->join($jobs, 'rec_jobs.id', ''.$job_applications.'.job_id')
            ->leftjoin($rec_job_skills, $jobs.'.id', 'rec_job_skills.job_id')
            ->leftjoin($rec_job_locations, 'rec_job_locations.id', $jobs.'.location_id')
            ->leftjoin($application_status, ''.$application_status.'.id', $job_applications.'.status_id')
            ->distinct()
            ->where($job_applications.'.job_id', $request->data['jobId'])
            ->where($application_status.'.status', '!=', 'rejected')
            ->pluck('application')->toArray();


            
        $jobApplications = JobApplication::select($job_applications.'.id', $job_applications.'.full_name', $job_applications.'.email', ''.$jobs.'.title',$rec_job_locations.'.location', $application_status.'.status', $application_status.'.color')->with('jobs')
            ->where($job_applications.'.status_id', '!=', ApplicationStatus::where('status', 'hired')->first()->id)
            ->join($jobs, $jobs.'.id', $job_applications.'.job_id')
            ->leftjoin($rec_job_skills, $jobs.'.id', $rec_job_skills.'.job_id')
            ->leftjoin($rec_job_locations, $rec_job_locations.'.id', ''.$jobs.'.location_id')
            ->leftjoin($application_status, $application_status.'.id', $job_applications.'.status_id');
           

         // return ApiHelper::JSON_RESPONSE(true, $jobApplications, '');  
        
        // Filter by status 
        if ($request->data['status'] != 'all' && $request->data['status'] != '') {
            $jobApplications = $jobApplications->where(''.$job_applications.'.status_id', $request->data['status']);
        }

        // Filter By jobs
        if ($request->data['jobId'] != 'all' && $request->data['jobId'] != '') {
            $jobApplications = $jobApplications->whereNotIn(''.$job_applications.'.id', $jobApplicationRec);
        }

        // Filter By skills
        if ($request->skill != 'all' && $request->skill != '') {
            $jobApplications = $jobApplications->whereIn('rec_job_skills.skill_id', gettype($request->skill) == 'array' ? $request->skill : explode(',', $request->skill));
        }

        // Filter by location
        if ($request->data['location'] != 'all' && $request->data['location'] != '') {
            $jobApplications = $jobApplications->where('rec_jobs.location_id', $request->data['location']);
        }

        // Filter by StartDate
        if ($request->data['startDate'] != null && $request->data['startDate'] != '') {
            $jobApplications = $jobApplications->where(DB::raw('DATE(rec_job_applications.`created_at`)'), '>=', $request->data['startDate']);
        }

        // Filter by EndDate
        if ($request->data['endDate'] != null && $request->data['endDate'] != '') {
            $jobApplications = $jobApplications->where(DB::raw('DATE(rec_job_applications.`created_at`)'), '<=', $request->data['endDate']);
        }

        // Filter by MailStatus
        if ($request->data['mailStatus'] != null && $request->data['mailStatus'] != '') {
            if ($request->data['mailStatus'] !== 'all') {
                if ($request->data['mailStatus'] == 'sent') {
                    $jobApplications = $jobApplications->whereHas('jobs', function ($q) use ($request) {
                        $q->where('job_id', $request->data['jobId']);
                    });
                } else {
                    $jobApplicationsCopy = clone $jobApplications;

                    $jobApplicationIds = $jobApplicationsCopy->whereHas('jobs', function ($q) use ($request) {
                        $q->where('job_id', $request->data['jobId']);
                    })->get()->map(function ($jobApplication) {
                        return $jobApplication->id;
                    })->toArray();

                    $jobApplications = $jobApplications->whereNotIn('rec_job_applications.id', $jobApplicationIds);
                }
            }
        }

        $jobApplications = $jobApplications->groupBy('rec_job_applications.id');
        $jobApplications = $jobApplications->get();

        


        return ApiHelper::JSON_RESPONSE(true, $jobApplications, ''); 
    }

   
}
