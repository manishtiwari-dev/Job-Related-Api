<?php

namespace Modules\Recruit\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Modules\Recruit\Models\ZoomSetting;
use App\Http\Controllers\Controller;
use ApiHelper;

class SettingController extends Controller
{

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index()
    {
        $zoom = ZoomSetting::first();


        $res = [
            'zoom' => $zoom,

        ];


        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request)
    {
        $setting = ZoomSetting::findOrFail($request->id);
        $setting->enable_zoom = ($request->enable_zoom) ? 1 : 0;

        $setting->update($request->all);

        return ApiHelper::JSON_RESPONSE(true, [], 'SETTING_UPDATE_SUCCESS');
    }
}
