<?php

namespace Modules\Recruit\Http\Controllers;

 
use App\Helper\Reply;
use Modules\Recruit\Models\JobLocation;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Location\StoreLocation;
use App\Http\Requests\Admin\Location\UpdateLocation;
use Yajra\DataTables\Facades\DataTables;
use App\Models\Country;
use Illuminate\Support\Facades\Validator;
use ApiHelper;

class LocationsController extends Controller
{
    

    public $page = 'job_location';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pageremove = 'remove';
    public $pageupdate = 'update';

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request) 
    { 

        $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

         $locations = JobLocation::with('country')->get();

        /*Binding data into a variable*/

        $res = [
            'locations' => $locations,

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    { 

        $countries = Country::all();


        $res = [
            'countries' => $countries,

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, ''); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

         $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');


        $locations = $request->locations;
        $country_id = $request->country_id;
       
        if (trim($locations[0]) == '') {
            return ApiHelper::JSON_RESPONSE(false, [], 'Location Name Can Not Be Blank');
        }


        foreach ($locations as $location) {
            if (!is_null($location)) {
                $data = JobLocation::create(['country_id' => $country_id, 'location' => $location]);
            }
        }

       if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_ADD_SKILLS'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_SKILLS_ADD');
        }
    }

    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {  
        $api_token = $request->api_token;

        $id = $request->id;
        $countries = Country::all();
        $location = JobLocation::find($id);

        $res = [
            'countries'=>$countries, 
            'location' => $location
            
        ];
        

          return ApiHelper::JSON_RESPONSE(true, $res,'');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    { 

         $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        $api_token = $request->api_token;
        $id = $request->id;

       $validator = Validator::make(
            $request->all(),
            [
                'location' => 'required',
                'country_id' => 'required',
            ],
            [

                'location.required' => 'LOCATION_NAME_FIELD_REQUIRED',
                'country_id.required' => 'COUNTRY_NAME_IS_REQUIRED',

            ]

        );

        if ($validator->fails()) {
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
        }


        $data = JobLocation::find($id);
        $data->location = $request->location;
        $data->country_id = $request->country_id;
        $data->save();


        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_UPDATE_LOCATION'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_LOCATION_UPDATE');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
         $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageremove))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');
    
         $data =JobLocation::destroy($request->id); 

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_DELETE_JOB_LOCATION'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_JOB_LOCATION_DELETE');
        }
    }

}
