<?php

namespace Modules\Recruit\Http\Controllers;

use App\Document;
use App\Helper\Files;
use App\Helper\Reply; 
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Yajra\DataTables\DataTables;
use ApiHelper;
use App\Http\Controllers\Controller;

class DocumentController extends Controller
{
     

    public function index(Request $request)
    { 


        $res = [
            'documentable_type' => $request->documentable_type,
            'documentable_id' => $request->documentable_id

        ];


        return ApiHelper::JSON_RESPONSE(true, $res, ''); 
       
    }

    public function store(Request $request)
    {

        $record = $request->documentable_type::with(['documents'])->select('id')->where('id', $request->documentable_id)->first();

        $hashname = Files::upload($request->file, 'documents/'.$request->documentable_id, null, null, false);

        $record->documents()->create([
            'name' => $request->name,
            'hashname' => $hashname
        ]);

         return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_ADD_SKILLS'); 
    }

    public function destroy(Document $document)
    {
        abort_if(!$this->user->cans('delete_job_applications'), 403);

        Files::deleteFile($document->hashname, 'documents/'.$document->documentable_id);

        $document->delete();

        return Reply::success(__('messages.documentDeletedSuccessfully'));
    }

    public function data(Request $request)
    {
        abort_if(!$this->user->cans('view_job_applications'), 403);

        $documents = $request->documentable_type::select('id')->with(['documents'])->where('id', $request->documentable_id)->first()->documents;

        return DataTables::of($documents)
            ->addColumn('action', function ($row) {
                $action = '';

                if ($this->user->cans('view_job_applications')) {
                    $action .= '<a href="' . route('admin.documents.downloadDoc', $row->id) . '" class="btn btn-success btn-circle"
                      data-toggle="tooltip" onclick="this.blur()" data-original-title="' . __('app.download') . '"><i class="fa fa-download" aria-hidden="true"></i></a>';
                }

                if ($this->user->cans('delete_job_applications')) {
                    $action .= ' <a href="javascript:;" class="btn btn-danger btn-circle delete-document"
                      data-toggle="tooltip" onclick="this.blur()" data-row-id="' . $row->id . '" data-original-title="' . __('app.delete') . '"><i class="fa fa-times" aria-hidden="true"></i></a>';
                }

                return $action;
            })
            ->editColumn('name', function ($row) {
                return ucwords($row->name);
            })
            ->rawColumns(['action'])
            ->addIndexColumn()
            ->make(true);
    }

    public function downloadDoc(Document $document)
    {
        abort_if(!$this->user->cans('view_job_applications'), 403);

        $filePath = public_path('user-uploads/documents/'.$document->documentable->id.'/'.$document->hashname);

        return response()->download($filePath, snake_case(strtolower($document->name)) . '.' . File::extension($filePath));
    }
}