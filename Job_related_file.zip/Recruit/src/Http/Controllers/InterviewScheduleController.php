<?php

namespace Modules\Recruit\Http\Controllers;


use Modules\Recruit\Models\ApplicationStatus;
use App\Helper\Reply;

use App\Http\Requests\InterviewSchedule\StoreRequest;
use App\Http\Requests\InterviewSchedule\UpdateRequest;
use Modules\Recruit\Models\InterviewSchedule;
use Modules\Recruit\Models\InterviewScheduleEmployee;
use Modules\Recruit\Models\JobApplication;
use Modules\Recruit\Models\Notifications\CandidateNotify;
use Modules\Recruit\Models\Notifications\CandidateReminder;
use Modules\Recruit\Models\Notifications\CandidateScheduleInterview;
use Modules\Recruit\Models\Notifications\EmployeeResponse;
use Modules\Recruit\Models\Notifications\ScheduleInterview;
use Modules\Recruit\Models\Notifications\ScheduleInterviewStatus;
use Modules\Recruit\Models\Notifications\ScheduleStatusCandidate;
use Modules\Recruit\Models\ZoomSetting;
use Modules\Recruit\Models\ZoomMeeting;
use Modules\Recruit\Models\ScheduleComments;
use MacsiDigital\Zoom\Facades\Zoom;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Notification;
use Yajra\DataTables\Facades\DataTables;
use ApiHelper;
use App\Http\Controllers\Controller;


class InterviewScheduleController extends Controller
{
    
    public $page = 'interview_schedule';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pageremove = 'remove';
    public $pageupdate = 'update';

    /**
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|mixed
     * @throws \Throwable
     */
    public function index(Request $request)
    { 

        $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');


        $currentDate = Carbon::now()->format('Y-m-d'); // Current Date

        // Get All schedules
        $schedules = InterviewSchedule::select('rec_interview_schedules.id', 'rec_interview_schedules.job_application_id', 'rec_interview_schedules.schedule_date', 'rec_interview_schedules.status')
            ->with(['employees', 'jobApplication:id,job_id,full_name', 'jobApplication.job:id,title'])
            ->join(config('dbtable.rec_job_applications'),'rec_job_applications.id', 'rec_interview_schedules.job_application_id')
            ->where('status', 'pending')
            ->whereNull('rec_job_applications.deleted_at')
            ->orderBy('schedule_date')
            ->get();

        // Filter upcoming schedule
        $upComingSchedules = $schedules->filter(function ($value, $key) use ($currentDate) {
            return $value->schedule_date >= $currentDate;
        });

        $upcomingData = [];

        // Set array for upcoming schedule
        foreach ($upComingSchedules as $upComingSchedule) {
            $dt = $upComingSchedule->schedule_date->format('Y-m-d');
            $upcomingData[$dt][] = $upComingSchedule;
        }

        $upComingSchedules = $upcomingData;

        $viewData = '';
        if ($request->ajax()) {
            $viewData = view('admin.interview-schedule.upcoming-schedule', $data)->render();
            return Reply::dataOnly(['data' => $viewData, 'scheduleData' => $schedules]);
        }

        $res = [

                'schedules' => $schedules,
                'currentDate' => $currentDate,
                'upComingSchedules' => $upComingSchedules,
                'viewData' => $viewData
            ];



        return ApiHelper::JSON_RESPONSE(true, $res, ''); 
    }


    /**
     * @param Request $request
     * @return string
     * @throws \Throwable
     */
    public function create(Request $request)
    {
         
         $candidates = JobApplication::all();
         $zoom_setting = ZoomSetting::first();
        $users = User::all();
        $scheduleDate = $request->date;

        $res = [
            'scheduleDate' => $scheduleDate,
             'candidates' => $candidates,
            'users' => $users,
            'zoom_setting' =>$zoom_setting,

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, ''); 
    }

    /**
     * @param Request $request
     * @return string
     * @throws \Throwable
     */
    public function table(Request $request)
    {
 
        $candidates = JobApplication::all();
        $users = User::all();
        $InterviewSchedules = InterviewSchedule::with('jobApplication')->get();
        
        $res = [
            'candidates' => $candidates,
            'users' => $users,
            'InterviewSchedules' => $InterviewSchedules

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, ''); 
    }

    /**
     * @param Request $request
     * @return mixed
     * @throws \Exception
     */
    public function data(Request $request)
    { 

 
        $jobapplication = config('dbtable.rec_job_applications');
        $interview_schedule_employees = config('dbtable.rec_interview_schedule_employees');
        $interview_schedules =config('dbtable.rec_interview_schedules');
        $rec_zoom_meetings =config('dbtable.rec_zoom_meetings');

       $shedule = InterviewSchedule::select(''.$interview_schedules.'.id',''.$interview_schedules.'.interview_type', ''.$interview_schedule_employees.'.user_id as employee_id',''.$jobapplication.'.full_name', ''.$interview_schedules.'.status', ''.$rec_zoom_meetings.'.created_by', ''.$rec_zoom_meetings.'.start_link' ,''.$interview_schedules.'.schedule_date')->leftjoin(''.$jobapplication.'', ''.$jobapplication.'.id', ''.$interview_schedules.'.job_application_id')->leftjoin(''.$interview_schedule_employees.'', ''.$interview_schedule_employees.'.interview_schedule_id', ''.$interview_schedules.'.id')->leftjoin(''.$rec_zoom_meetings.'', ''.$rec_zoom_meetings.'.id', ''.$interview_schedules.'.meeting_id')->whereNull(''.$jobapplication.'.deleted_at');


      // $shedule = InterviewSchedule::with('jobApplication','employee')->get();


        // Filter by status
        if ($request->status != 'all' && $request->status != '') {
            $shedule = $shedule->where(''.$interview_schedules.'.status', $request->status);
        }

        // Filter By candidate
        if ($request->applicationID != 'all' && $request->applicationID != '') {
            $shedule = $shedule->where(''.$jobapplication.'.id', $request->applicationID);
        }

        // Filter by StartDate
        if ($request->startDate !== null && $request->startDate != 'null') {

            $shedule = $shedule->where(DB::raw('DATE('.$interview_schedules.'.`schedule_date`)'), '>=', "$request->startDate");
        }

        // Filter by EndDate
        if ($request->endDate !== null && $request->endDate != 'null') {
            $shedule = $shedule->where(DB::raw('DATE('.$interview_schedules.'.`schedule_date`)'), '<=', "$request->endDate");
        }

        $shedule = $shedule->get();
        $zoomSetting = ZoomSetting::first();

        $res = [

                'shedule' => $shedule, 
                'zoomSetting' => $zoomSetting
            ]; 



        return ApiHelper::JSON_RESPONSE(true, $res, ''); 



    }

    /**
     * @param $id
     * @return string
     * @throws \Throwable
     */
    public function edit(Request $request)
    { 

        $api_token = $request->api_token;
        $user_id = ApiHelper::get_user_id_from_token($api_token);

        $id = $request->id;

        $candidates = JobApplication::all();
        $users = User::all(); 
        $zoom_setting = ZoomSetting::first();
        $schedule = InterviewSchedule::with(['jobApplication', 'user','meeting'])->find($id);
        $comment = ScheduleComments::where('interview_schedule_id', $schedule->id)->first();
        $employeeList = json_encode($schedule->employee->pluck('user_id')->toArray());
 

        $res = [
            'candidates'=>$candidates, 
            'users' => $users,
            'schedule' => $schedule,
            'comment' => $comment,
            'employeeList' => $employeeList,
            'zoom_setting' => $zoom_setting,
            'user' => $user_id
        ];
        

          return ApiHelper::JSON_RESPONSE(true, $res,'');
    }

    /**
     * @param StoreRequest $request
     * @return array
     */
    public function store(Request $request) 
    {
        $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        $user_id = ApiHelper::get_user_id_from_token($api_token);

        $dateTime =  $request->scheduleDate . ' ' . $request->scheduleTime; 

        
        if($request->interview_type == 'online'){
            $data = $request->all;

            $meeting = new ZoomMeeting();
            $meeting->created_by = $data['created_by'];
            $meeting->meeting_name = $data['meeting_title'];
            $meeting->start_date_time = $dateTime;
            $meeting->end_date_time = $data['end_date'] . ' ' . $data['end_time'];
            $meeting->remind_time = $data['remind_time'];
            $meeting->remind_type = $data['remind_type'];
            $meeting->host_video = $data['host_video'];
            $meeting->participant_video =  $data['participant_video'];
            $meeting->save();

            // $data['meeting_name'] = $request->meeting_title;
            // $data['start_date_time'] = $dateTime;
            // $data['end_date_time'] = $request->end_date . ' ' . $request->end_time;
            // $meeting = $meeting->create($data);

            $host = User::find($request->created_by);
            $user = Zoom::user()->find('me');
            $meetings = $this->createMeeting($user, $meeting,  null, $host);
        } 
        else{
            $meetings = '';
        }  
            // store Schedule
            $interviewSchedule = new InterviewSchedule();
            $interviewSchedule->job_application_id = $request->candidates;
            $interviewSchedule->schedule_date = $dateTime;
            $interviewSchedule->interview_type = ($request->has('interview_type')) ? $request->interview_type : 'offline';
            $interviewSchedule->interview_type = $request->interview_type;
            // $interviewSchedule->meeting_id = ($meetings!= '') ? $meetings->id: null;
            $interviewSchedule->save();

          

            // Update Schedule Status
            $jobApplication = $interviewSchedule->jobApplication;
            $jobApplication->status_id = 3;
            $jobApplication->save();

            if ($request->comment) {
                $scheduleComment = [
                    'interview_schedule_id' => $interviewSchedule->id,
                    'user_id' => $user_id,
                    'comment' => $request->comment
                ];

                $interviewSchedule->comments()->create($scheduleComment);
            }

            if (!empty($request->employees)) {
                $interviewSchedule->employees()->attach($request->employees);

                // Mail to employee for inform interview schedule
                // Notification::send($interviewSchedule->employees, new ScheduleInterview($jobApplication,$meetings));
            }

            
       return ApiHelper::JSON_RESPONSE(true, [], 'STORE_INTERVIEW_SCHEDULE_SUCCESS'); 
    }
 
 
    public function changeStatus(Request $request)
    {
        abort_if(!$this->user->cans('add_schedule'), 403);

        $this->commonChangeStatusFunction($request->id, $request);

        return Reply::success(__('messages.interviewScheduleStatus'));
    }

    /**
     * @param UpdateRequest $request
     * @param $id
     * @return array
     */
    public function update(Request $request)
    {
        
 $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');
    
        $dateTime =  $request->scheduleDate . ' ' . $request->scheduleTime;
        $dateTime = Carbon::createFromFormat('Y-m-d H:i', $dateTime);

        // Update interview Schedule
        $interviewSchedule = InterviewSchedule::select('id', 'job_application_id','interview_type', 'schedule_date', 'status')
            ->with([
                'jobApplication:id,full_name,email,job_id,status_id',
                'employees',
                'comments'
            ])
            ->where('id', $request->id)->first();
        $interviewSchedule->schedule_date = $dateTime;
        if(!is_null($request->interview_type)){
            $interviewSchedule->interview_type = $request->interview_type;

        }else{
            $interviewSchedule->interview_type =  $interviewSchedule->interview_type;
       
        }
       
        if($request->interview_type == 'offline' ){
            $interviewSchedule->meeting_id = null;
            ZoomMeeting::where('id',$interviewSchedule->meeting_id)->delete();
            $meeting ='';
        }
        $interviewSchedule->save();

        if ($request->comment) {
            $scheduleComment = [
                'comment' => $request->comment
            ];

            $interviewSchedule->comments()->updateOrCreate([
                'interview_schedule_id' => $interviewSchedule->id,
                // 'user_id' => $this->user->id
            ], $scheduleComment);
        }

        $jobApplication = $interviewSchedule->jobApplication;
            //zoom meeting update
        $host = User::find($request->create_by);

        if($request->interview_type == 'online'){
            $user = Zoom::user()->find('me');

            $meeting = is_null($interviewSchedule->meeting_id) ? new ZoomMeeting() : ZoomMeeting::find($interviewSchedule->meeting_id);
            $data = $request->all();
            $data['meeting_name'] = $request->meeting_title;
            $data['start_date_time'] = $request->start_date . ' ' . $request->start_time;
            $data['end_date_time'] = $request->end_date . ' ' . $request->end_time;
            if (is_null($interviewSchedule->meeting_id)) {
                $meeting = $meeting->create($data);
            } else {
                $meeting->update($data);

            }

            $meetings = $this->createMeeting($user, $meeting, $interviewSchedule->meeting_id, null, $host);
            $interviewSchedule->meeting_id = $meetings->id;
            $interviewSchedule->save();
        }
        if (!empty($request->employee)) {
            $interviewSchedule->employees()->sync($request->employee);
            if(!($request->interview_type)){
                $meeting = '';
            }
        }
        //     // Mail to employee for inform interview schedule
        //     Notification::send($interviewSchedule->employees, new ScheduleInterview($jobApplication,$meeting));

        // }

         return ApiHelper::JSON_RESPONSE(true, [], 'UPDATE_INTERVIEW_SCHEDULE_SUCCESS'); 
    }

    /**
     * @param $id
     * @return array
     */
    public function destroy(Request $request)
    { 
        
        $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageremove))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');



         $data = InterviewSchedule::select('meeting_id')->where('id',$request->id)->get();
         InterviewSchedule::destroy($request->id);

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_DELETE_InterviewSchedule'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_InterviewSchedule_DELETE');
        }

    }

    /**
     * @param $id
     * @return string
     * @throws \Throwable
     */
    public function show(Request $request)
    {

        $schedule = InterviewSchedule::with(['jobApplication', 'user'])->find($request->id);
        $currentDateTimestamp = Carbon::now()->timestamp;
        $tableData = null;
        $zoom_setting = ZoomSetting::first();

        $res = [
            'schedule' => $schedule,
            'currentDateTimestamp' => $currentDateTimestamp,
            'tableData' => $tableData,
            'zoom_setting' => $zoom_setting
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, 'SUCCESS'); 
       
    }

    // notify and reminder to candidate on interview schedule
    public function notify($id, $type)
    {

        $jobApplication = JobApplication::find($id);

        if ($type == 'notify') {
            // mail to candidate for hiring notify
            Notification::send($jobApplication, new CandidateNotify());
            return Reply::success(__('messages.notificationForHire'));
        } else {
            // mail to candidate for interview reminder
            Notification::send($jobApplication, new CandidateReminder($jobApplication->schedule));
            return Reply::success(__('messages.notificationForReminder'));
        }
    }

    // Employee response on interview schedule
    public function employeeResponse($id, $res)
    {

        $scheduleEmployee = InterviewScheduleEmployee::find($id);
        $users = User::allAdmins(); // Get All admins for mail
        $type = 'refused';

        if ($res == 'accept') {
            $type = 'accepted';
        }

        $scheduleEmployee->user_accept_status = $res;

        // mail to admin for employee response on refuse or accept
        Notification::send($users, new EmployeeResponse($scheduleEmployee->schedule, $type, $this->user));

        $scheduleEmployee->save();

        return Reply::success(__('messages.responseAppliedSuccess'));
    }

    public function changeStatusMultiple(Request $request)
    {

        foreach ($request->id as $ids) {
            $this->commonChangeStatusFunction($ids, $request);
        }

        return ApiHelper::JSON_RESPONSE(true, [], 'CHANGE_STATUS_SUCCESS'); 
    }

    public function commonChangeStatusFunction($id, $request)
    {
        // store Schedule
        $interviewSchedule = InterviewSchedule::select('id', 'job_application_id', 'status')
            ->with([
                'jobApplication:id,full_name,email,job_id,status_id',
                'employees'
            ])
            ->where('id', $id)->first();


        $interviewSchedule->status = $request->status;
        $interviewSchedule->save();

        $application = $interviewSchedule->jobApplication;
        $status = ApplicationStatus::select('id', 'status');

        if (in_array($request->status, ['rejected', 'canceled'])) {
            $applicationStatus = $status->status('rejected');
        }
        if ($request->status === 'hired') {
            $applicationStatus = $status->status('hired');
        }
        if ($request->status === 'pending') {
            $applicationStatus = $status->status('interview');
        }

        $application->status_id = $applicationStatus->id;

        $application->save();

        $employees = $interviewSchedule->employees;
        $admins = User::all();

        $users = $employees->merge($admins);

        // if ($users && $request->mailToCandidate ==  'yes') {
        //     // Mail to employee for inform interview schedule
        //     Notification::send($users, new ScheduleInterviewStatus($application));
        // }

        // if ($request->mailToCandidate ==  'yes') {
        //     // mail to candidate for inform interview schedule status
        //     Notification::send($application, new ScheduleStatusCandidate($application, $interviewSchedule));
        // }

        return;
    }
}
