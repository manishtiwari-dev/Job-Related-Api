<?php

namespace Modules\Recruit\Http\Controllers;

use App\Helper\Reply; 
use Modules\Recruit\Models\Question; 
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;
use ApiHelper;
use Illuminate\Support\Facades\Validator;




class QuestionController extends Controller
{


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $questions = Question::all();
         $res = [
            
            'questions' => $questions,
        ];


        return ApiHelper::JSON_RESPONSE(true, $res, ''); 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
          
        $res = [
             

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, ''); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    { 


        $validator = Validator::make(
            $request->all(),
            [
                'question' => 'required', 
                'type' => 'required',
            ],
            [

                'question.required' => 'QUESTIONS_FIELD_REQUIRED',
                'type.required' => 'TYPE_FIELD_REQUIRED',

            ]

        );


        if ($validator->fails()) {
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
        }


        $data = new Question();
        $data->question = $request->question;
        $data->required = $request->required;
        $data->type = $request->type;

        $data->save();

        

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_ADD_QUESTIONS'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_QUESTIONS_ADD');
        }


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $id = $request->id; 

        $question = Question::find($id);
         

        $res = [
            'question'=>$question,              
        ];
        

          return ApiHelper::JSON_RESPONSE(true, $res,'');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    { 

        

        $validator = Validator::make(
            $request->all(),
            [
                'question' => 'required', 
                'type' => 'required',
            ],
            [

                'question.required' => 'QUESTIONS_FIELD_REQUIRED',
                'type.required' => 'TYPE_FIELD_REQUIRED',

            ]

        );


        if ($validator->fails()) {
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
        }


        $data = Question::find($request->id);
        $data->question = $request->question;
        $data->required = $request->required;
        $data->type = $request->type;
        $data->save();

        

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_ADD_QUESTIONS'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_QUESTIONS_ADD');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
         

        $data =Question::destroy($request->id); 

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_DELETE_QUESTIONS'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_QUESTIONS_DELETE');
        }
    }

    

}
