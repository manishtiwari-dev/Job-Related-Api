<?php

namespace Modules\Recruit\Http\Controllers;


use Modules\HRM\Models\Staff;
use Modules\Recruit\Models\Onboard;
use App\Models\Currency; 
use Modules\HRM\Models\Department;
use Modules\HRM\Models\Designation;
use App\Helper\Files;
use App\Helper\Reply;
use Modules\Recruit\Models\OnboardFiles;
use Modules\Recruit\Models\JobApplication;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Modules\Recruit\Models\Notifications\JobOffer;
use Illuminate\Support\Facades\File;
use Yajra\DataTables\Facades\DataTables;
use App\Http\Requests\Onboard\StoreRequest;
use App\Http\Requests\Onboard\UpdateStatus;
use Modules\Recruit\Models\JobOfferQuestion;
use Modules\Recruit\Models\JobOnboardQuestion;
use Modules\Recruit\Models\OnboardAnswer;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Notification;
use ApiHelper;


class JobOnboardController extends Controller
{
    

    public $page = 'job_onboard';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pageremove = 'remove';
    public $pageupdate = 'update';



    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');
         
        return ApiHelper::JSON_RESPONSE(true, [], '');
    }

    public function create(Request $request)
    {
        

        $application = JobApplication::with(['job', 'status', 'job.location'])->findOrFail($request->id);


        $users        = Staff::all();
        $departments  = Department::all();
        $designations = Designation::all();
        $currencies = Currency::all();
        $questions = JobOfferQuestion::all();

        $res = [
            'application' => $application,
            'users' => $users,
            'departments' => $departments,
            'currencies' => $currencies,
            'questions' => $questions,
            'designations' => $designations

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, ''); 

    }

    /**
     * @param StoreRequest $request
     * @return array
     */
    public function store(Request $request)
    {
        $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        // Save On Board Details
        $onBoard = new Onboard();
        $onBoard->job_application_id = $request->candidate_id;
        $onBoard->department_id      = $request->department;
        $onBoard->designation_id     = $request->designation;
        $onBoard->currency_id        = $request->currency_id; 
        $onBoard->salary_offered     = $request->salary;
        $onBoard->joining_date       = $request->join_date;
        $onBoard->reports_to_id      = $request->report_to;
        $onBoard->employee_status    = $request->employee_status;
        $onBoard->accept_last_date   = $request->last_date;
        $onBoard->offer_code         = Str::random(18);
        $onBoard->save();

        $onBoard->onboardQuestion()->sync($request->question);

        return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_ADD_JOB_ONBOARD'); 
        
        $names = $request->name;
        $files = $request->hasFile('photo');


        if ($request->hasFile('photo')) {
            foreach ($names as $key => $name) :
                // Files store in directory 

                $extension=$files[$key]->extension();
                $fileN=time();
                $fileName = $fileN.'.'.$extension;
                $path = $files[$key]->move(public_path('/recruit/profile'), $fileName);
 

                if (is_null($name)) {
                    $name = $files[$key]->getClientOriginalName();
                }
                
                // Files save
                OnboardFiles::create(
                    [
                        'on_board_detail_id' => $onBoard->id,
                        'name' => $name,
                        'file' => $files[$key]->getClientOriginalName(),
                        'hash_name' => $fileName
                    ]
                );
            endforeach;
        }

        // // Send Offer email
        // if ($request->has('send_email')) {
        //     $this->sendOffer($request->candidate_id);
        // }
        

        return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_ADD_JOB_ONBOARD'); 
    }

    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function edit(Request $request)
    {
         // images format with icon
        $imageExt = [
            'png' => 'fa-file-image-o',  'jpe' => 'fa-file-image-o', 'jpeg' => 'fa-file-image-o', 'jpg' => 'fa-file-image-o',
            'gif' => 'fa-file-image-o',  'bmp' => 'fa-file-image-o', 'ico' => 'fa-file-image-o', 'tiff' => 'fa-file-image-o',
            'tif' => 'fa-file-image-o', 'svg' => 'fa-file-image-o', 'svgz' => 'fa-file-image-o',
        ];

        // adobe and ms office files format with icon
        $fileExt = [
            // adobe
            'pdf' => 'fa-file-pdf-o', 'psd' => 'fa-file-image-o', 'ai' => 'fa-file-o', 'eps' => 'fa-file-o',
            'ps' => 'fa-file-o',
            // ms office
            'doc' => 'fa-file-text', 'rtf' => 'fa-file-text', 'xls' => 'fa-file-excel-o', 'ppt' => 'fa-file-powerpoint-o',
            'docx' => 'fa-file-text', 'xlsx' => 'fa-file-excel-o', 'pptx' => 'fa-file-powerpoint-o',
            // open office
            'odt' => 'fa-file-text', 'ods' => 'fa-file-text',
        ];

        $onboard      = Onboard::with(['reportto', 'files'])->findOrFail($request->id);
        $application  = JobApplication::with(['job', 'status', 'job.location'])->findOrFail($onboard->job_application_id);
        $users        = Staff::all();
        $departments  = Department::all();
        $designations = Designation::all();
        $currencies = Currency::all();
        $questions = JobOfferQuestion::all();
        $onboardQuestion = $onboard->onboardQuestion->pluck('id')->toArray();
        
        $res = [
            'onboard'=>$onboard, 
            'application' => $application,
            'users' => $users,
            'designations' => $designations,
            'currencies' => $currencies,
            'questions' => $questions,
            'onboardQuestion' => $onboardQuestion, 
            'departments' => $departments
            
        ];

        return ApiHelper::JSON_RESPONSE(true, $res,'');
    }

    /**
     * @param Request $request
     * @return mixed
     */
    public function data(Request $request)
    { 
         $job_applications = config('dbtable.rec_job_applications');
        $interview_schedule_employees = config('dbtable.rec_interview_schedule_employees');
        $interview_schedules =config('dbtable.rec_interview_schedules');
        $rec_job_locations = config('dbtable.rec_job_locations');
        $rec_application_status = config('dbtable.rec_application_status');
        $on_board_details = config('dbtable.rec_on_board_details');
        $rec_jobs = config('dbtable.rec_jobs');

        $jobApplications = Onboard::select(''.$on_board_details.'.id', ''.$job_applications.'.id as application_id', ''.$job_applications.'.full_name', ''.$rec_jobs.'.title', ''.$rec_job_locations.'.location', ''.$on_board_details.'.joining_date', ''.$on_board_details.'.accept_last_date', ''.$on_board_details.'.hired_status')
            ->join(''.$job_applications.'', ''.$job_applications.'.id', ''.$on_board_details.'.job_application_id')
            ->leftJoin(''.$rec_jobs.'', ''.$rec_jobs.'.id', ''.$job_applications.'.job_id')
            ->leftjoin(''.$rec_job_locations.'', ''.$rec_job_locations.'.id', ''.$rec_jobs.'.location_id')
            ->leftjoin(''.$rec_application_status.'', ''.$rec_application_status.'.id', ''.$job_applications.'.status_id');

            $jobApplications = $jobApplications->get();

        $res = [

                'jobApplications' => $jobApplications, 
            ];


        return ApiHelper::JSON_RESPONSE(true, $res, ''); 
    }

    /**
     * @param StoreRequest $request
     * @param $id
     * @return array
     */
    public function update(Request $request)
    {

          $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

    
        // update On Board Details
        $onBoard = Onboard::findOrFail($request->id);
        $onBoard->job_application_id = $request->candidate_id;
        $onBoard->department_id      = $request->department;
        $onBoard->designation_id     = $request->designation;
        $onBoard->currency_id        = $request->currency_id;
        $onBoard->salary_offered     = $request->salary;
        $onBoard->joining_date       = $request->join_date;
        $onBoard->reports_to_id      = $request->report_to;
        $onBoard->employee_status    = $request->employee_status;
        $onBoard->accept_last_date   = $request->last_date;
        $onBoard->hired_status       = $request->status;

        if ($onBoard->hired_status == 'rejected' || $onBoard->hired_status == 'canceled') {
            $onBoard->hired_status       = $request->reason;
        }

        $onBoard->save();
        $onBoard->onboardQuestion()->sync($request->question);

        $names = $request->name;
        $files = $request->file;

return ApiHelper::JSON_RESPONSE(true, $names, 'SUCCESS_ADD_JOB_ONBOARD'); 
        // if ($request->has('file')) {
        //     foreach ($names as $key => $name) :
        //         if (isset($files[$key])) {
        //             // Files store in directory
        //             $fileName = Files::upload($files[$key], 'onboard-files', null, null, false);

        //             // Files save
        //             OnboardFiles::create(
        //                 [
        //                     'on_board_detail_id' => $onBoard->id,
        //                     'name'               => $name,
        //                     'file'               => $files[$key]->getClientOriginalName(),
        //                     'hash_name'          => $fileName
        //                 ]
        //             );
        //         }

        //     endforeach;
        // }


         return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_UPDATE_JOB_ONBOARD'); 
    }

    /**
     * @param $id
     * @return array
     */
    public function destroy(Request $request)
    {
         $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageremove))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');
    
        $onBoardFiles = OnboardFiles::findOrFail($request->id);
        File::delete('user-uploads/onboard-files/' . $onBoardFiles->hashName);

        OnboardFiles::destroy($request->id);
        return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_DELETE_JOB_ONBOARD'); 
    }

    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function show(Request $request)
    {
        // images format with icon
        $imageExt = [
            'png' => 'fa-file-image-o',  'jpe' => 'fa-file-image-o', 'jpeg' => 'fa-file-image-o', 'jpg' => 'fa-file-image-o',
            'gif' => 'fa-file-image-o',  'bmp' => 'fa-file-image-o', 'ico' => 'fa-file-image-o', 'tiff' => 'fa-file-image-o',
            'tif' => 'fa-file-image-o', 'svg' => 'fa-file-image-o', 'svgz' => 'fa-file-image-o',
        ];

        // adobe and ms office files format with icon
        $fileExt = [
            // adobe
            'pdf' => 'fa-file-pdf-o', 'psd' => 'fa-file-image-o', 'ai' => 'fa-file-o', 'eps' => 'fa-file-o',
            'ps' => 'fa-file-o',
            // ms office
            'doc' => 'fa-file-text', 'rtf' => 'fa-file-text', 'xls' => 'fa-file-excel-o', 'ppt' => 'fa-file-powerpoint-o',
            'docx' => 'fa-file-text', 'xlsx' => 'fa-file-excel-o', 'pptx' => 'fa-file-powerpoint-o',
            // open office
            'odt' => 'fa-file-text', 'ods' => 'fa-file-text',
        ];
        $onboard      = Onboard::with('reportto', 'files', 'currency')->findOrFail($request->id);
        $application  = JobApplication::with(['job', 'status', 'job.location'])->findOrFail($onboard->job_application_id);  
        //$answers = OnboardAnswer::with(['question'])
            // ->where('onboard_id', $onboard->id)
            // ->get();

            $res = [
                'imageExt' => $imageExt,
                'fileExt' => $fileExt,
                'onboard' => $onboard,
                'application' => $application,
                // 'answers' => $answers

            ];

        return ApiHelper::JSON_RESPONSE(true, $res, ''); 

    
    }

    /**
     * @param $userID
     */
    public function sendOffer(Request $request)
    {
        $jobApplication = JobApplication::select('id', 'job_id', 'full_name', 'email')->with(['job:id,title', 'onboard:id,offer_code,job_application_id,hired_status'])->where('id', $request->userID)->first();

        if ($jobApplication->onboard->hired_status !== 'offered') {
            $jobApplication->onboard->hired_status = 'offered';

            $jobApplication->onboard->save();
        }
        // Send Email Or Sms to applicant.Request
        //$jobApplication->notify(new JobOffer($jobApplication));

       return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS'); 
    }

    /**
     * @param $id
     * @return array
     */
    public function updateStatus(Request $request)
    {
        $onboard = Onboard::findOrFail($request->id);
        $onboard->cancel_reason = $request->cancel_reason;
        $onboard->hired_status = 'canceled';
        $onboard->save();   

        return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_CANCELED_JOB_ONBOARD'); 
    }
}
