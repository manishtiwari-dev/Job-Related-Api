<?php

namespace Modules\Recruit\Http\Controllers;


use App\Helper\Reply;
use App\Http\Requests\StoreJobCategory;
use Modules\Recruit\Models\JobCategory;
use Modules\Recruit\Models\Skill;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Validator;
use ApiHelper;


class JobCategoryController extends Controller
{

        
    public $page = 'job_categories';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pageremove = 'remove';
    public $pageupdate = 'update';

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        $job_category = JobCategory::get();

        /*Binding data into a variable*/

        $res = [
            'job_category' => $job_category,

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return ApiHelper::JSON_RESPONSE(true, [], ''); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    { 

         $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');
    
 
        $names = $request->name;

        if (trim($names[0]) == '') {
            return ApiHelper::JSON_RESPONSE(false, $names, 'Category cannot be blank');
        }

        foreach ($names as $name) {
            if (is_null($name)) { 
            return ApiHelper::JSON_RESPONSE(false, $names, 'Category cannot be blank');
            }
        }

        foreach ($names as $key => $name):
            if(!is_null($name)){
               $data =  JobCategory::create(['name' => $name]);
            }
        endforeach;
        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_ADD_JOB_CATEGORY'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_JOB_CATEGORY_ADD');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)

    {  
       $api_token = $request->api_token;
        $id = $request->id;

        $jobcategory = JobCategory::find($id);

        $res = [
            'jobcategory'=>$jobcategory, 
            
        ];
        

          return ApiHelper::JSON_RESPONSE(true, $res,'');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $api_token = $request->api_token;
      
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        $data = JobCategory::find($request->id);
        $data->name = $request->name;
        $data->save();


        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_UPDATE_JOB_CATEGORY'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_JOB_CATEGORY_UPDATE');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    { 
   
        $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageremove))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');
    
        $data =JobCategory::destroy($request->id); 

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_DELETE_JOB_CATEGORY'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_JOB_CATEGORY_DELETE');
        }

    }



    public function getSkills(Request $request){
 
        $data = Skill::where('category_id', $request->categoryId)->get();

        

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR');
        }
    }

}
