<?php

namespace Modules\Recruit\Http\Controllers;

use Illuminate\Http\Request;
use Modules\Recruit\Models\ApplicantNote;
use App\Http\Controllers\Controller;
use ApiHelper;

class ApplicantNoteController extends Controller
{

    public function store(Request $request)
    {  
        $api_token = $request->api_token;
        $user_id = ApiHelper::get_user_id_from_token($api_token);

        $note = new ApplicantNote();
        $note->note_text = $request->note;
        $note->user_id = $user_id;
        $note->job_application_id = $request->id;
        $note->save();

        $notes = ApplicantNote::where('job_application_id', $request->id)->orderBy('id', 'desc')->get();

        $res=[
            'notes' => $notes
        ];

        
        return ApiHelper::JSON_RESPONSE(true, $res, 'SUCCESS_ADD_NOTES'); 
         
    }

    public function update(Request $request)
    {

        $api_token = $request->api_token;
        $user_id = ApiHelper::get_user_id_from_token($api_token);


        $note = ApplicantNote::find($request->id);
        $note->note_text = $request->note;
        $note->user_id = $user_id;
        $note->save();

        $notes = ApplicantNote::where('job_application_id', $note->job_application_id)->orderBy('id', 'desc')->get();

        $res=[
            'notes' => $notes
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, 'SUCCESS_UPDATE_NOTES'); 
       
    }

    public function destroy(Request $request)
    {
        $note = ApplicantNote::find($request->id);
        ApplicantNote::destroy($request->id);

        $notes = ApplicantNote::where('job_application_id', $note->job_application_id)->orderBy('id', 'desc')->get();

        $res=[
            'notes' => $notes
        ];

         return ApiHelper::JSON_RESPONSE(true, $res, 'SUCCESS_DELETE_NOTES'); 
    }

}
