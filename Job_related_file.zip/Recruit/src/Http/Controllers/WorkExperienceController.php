<?php

namespace Modules\Recruit\Http\Controllers;

use Modules\Recruit\Models\JobType;
use Modules\Recruit\Models\Department;
use App\Helper\Reply;
use Modules\Recruit\Models\WorkExperience;
use Illuminate\Http\Request; 
use App\Http\Controllers\Controller;
use ApiHelper;

class WorkExperienceController extends Controller
{
     

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    public function create()
    { 

        $workExperiences = WorkExperience::all();


         $res = [
            'workExperiences' => $workExperiences, 
        ];

          return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function edit($id)
    {
       //
    }

    public function store(Request $request)
    {
       
        $data = new WorkExperience;
        $data->work_experience = $request->work_experience;
        $data->save();

         $data = WorkExperience::all();

         if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_ADD_WORK_EXPERIENCE'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_WORK_EXPERIENCE_ADD');
        }


    }

    public function update(Request $request)
    {
        
         
        $data = WorkExperience::findOrFail($request->id);
        $data->work_experience = $request->work_experience;
        $data->save();

        $data = WorkExperience::all();

         if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_UPDATE_WORK_EXPERIENCE'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_WORK_EXPERIENCE_UPDATE');
        }


    }

    public function destroy(Request $request)
    {

        WorkExperience::destroy($request->id);

        
        $data = WorkExperience::all();

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_DELETE_WORK_EXPERIENCE'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_WORK_EXPERIENCE_DELETE');
        }
    }

    public function show($id)
    {
        //
    }
}
