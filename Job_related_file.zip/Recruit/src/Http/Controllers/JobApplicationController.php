<?php

namespace Modules\Recruit\Http\Controllers;
use Modules\Recruit\Models\Job;
use app\Models\User;
use Modules\Recruit\Models\Skill;
use Modules\Recruit\Models\Question;
use Carbon\Carbon;
use Modules\Recruit\Models\JobLocation;
use Modules\Recruit\Models\ZoomMeeting;
use Modules\Recruit\Models\ZoomSetting; 
use Modules\Recruit\Models\JobApplication;
use Modules\Recruit\Models\ApplicationStatus;
use Modules\Recruit\Models\InterviewSchedule;
use Modules\Recruit\Models\ApplicationSetting;
use Illuminate\Support\Arr;
use Illuminate\Http\Request;
use Modules\Recruit\Models\JobApplicationAnswer;
use Illuminate\Support\Facades\DB;
use MacsiDigital\Zoom\Facades\Zoom;
use Maatwebsite\Excel\Facades\Excel;
use Modules\Recruit\Exports\JobApplicationExport;
use Illuminate\Support\Facades\Storage;
use App\Jobs\ScheduleInterview;
use Yajra\DataTables\Facades\DataTables;
use Maatwebsite\Excel\Excel as ExcelExcel;
use App\Http\Controllers\Controller;
use ApiHelper;


class JobApplicationController extends Controller
{
   

    public $page = 'job_applications';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pageremove = 'remove';
    public $pageupdate = 'update';

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
         $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');


        $rec_jobs = config('dbtable.rec_jobs');
        $date = Carbon::now();
        $type = ($request->has('type')) ? 'dash' : '';
        $startDate = $date->subDays(30)->format('Y-m-d');
        $endDate = Carbon::now()->format('Y-m-d');
        $jobs = Job::all();
        $skills = Skill::all();
        $questions = Question::all();
         $boardColumns = ApplicationStatus::withCount(['applications as application_count' => function ($q) use ($startDate, $endDate, $request) {
          
             if ($request->startDate !== null && $request->startDate != 'null' && $request->startDate != '') {
                $q = $q->where(DB::raw('DATE(rec_job_applications.`created_at`)'), '>=', $request->startDate);
               } else {
             }

             if ($request->endDate !== null && $request->endDate != 'null' && $request->endDate != '') {
                 $q = $q->where(DB::raw('DATE(rec_job_applications.`created_at`)'), '<=', $request->endDate);
             } else {
             }

            // Filter By jobs
             if ($request->jobs != 'all' && $request->jobs != '') {
                 $q = $q->where('rec_job_applications.job_id', $request->jobs);
             }

            // Filter by EndDate
            if ($request->search != null && $request->search != '') {
                $q = $q->where('full_name', 'LIKE', '%' . $request->search . '%')
                        ->orWhere('email', 'LIKE', '%' . $request->search . '%')
                        ->orWhere('phone', 'LIKE', '%' . $request->search . '%');
            }

            // Filter  by Location
            if ($request->location != 'all' && $request->location != '')
            {
                  $rec = config('dbtable.rec_jobs');
                $q->leftJoin(''.$rec.'', 'rec_jobs.id', 'rec_job_applications.job_id')
                    ->where('rec_jobs.location_id', '=', $request->location);
            }

            if($request->questions != 'all' && $request->questions != ''){
            $job_questions = config('dbtable.rec_job_questions');
               $q->join(''.$job_questions.'', 'rec_job_questions.job_id', 'rec_job_applications.job_id')
                    ->where('rec_job_questions.question_id', '=', $request->questions);
            }

            if($request->question_value != '' && $request->questions != 'all' && $request->questions != ''){
                
                $q->join('job_application_answers', 'job_application_answers.job_application_id', 'rec_job_applications.id')
                ->where('job_application_answers.question_id',  $request->questions)
                ->where('job_application_answers.answer', 'LIKE', '%' . $request->question_value . '%');
            }


            // Filter by skills
            if ($request->skill != 'all' && $request->skill != '') {
                foreach (explode(',', $request->skill) as $key => $skill) {
                    if ($key == 0) {
                         $q->whereJsonContains('skills', $skill);
                    }
                    else {
                         $q->orWhereJsonContains('skills', $skill);
                    }
                }
            }

        }])
        ->with(['applications' => function ($r) use ($startDate, $endDate, $request) {
            $r = $r->select('rec_job_applications.*');
            if ($request->startDate !== null && $request->startDate != 'null' && $request->startDate != '') {
                $r = $r->where(DB::raw('DATE(rec_job_applications.`created_at`)'), '>=', $request->startDate);
            } else {
            }

            if ($request->endDate !== null && $request->endDate != 'null' && $request->endDate != '') {
                $r = $r->where(DB::raw('DATE(rec_job_applications.`created_at`)'), '<=', $request->endDate);
            } else {
            }

            // Filter By jobs
            if ($request->jobs != 'all' && $request->jobs != '') {
                $r = $r->where('rec_job_applications.job_id', $request->jobs);
            }

            // Filter by EndDate
            if ($request->search != null && $request->search != '') {
                $r = $r->where('full_name', 'LIKE', '%' . $request->search . '%')
                        ->orWhere('email', 'LIKE', '%' . $request->search . '%')
                        ->orWhere('phone', 'LIKE', '%' . $request->search . '%');
            }

            // Filter  by Location
            if ($request->location != 'all' && $request->location != '')
            {
                $rec_job = config('dbtable.rec_jobs');
                $r->leftJoin(''.$rec_job.'', 'rec_jobs.id', 'rec_job_applications.job_id')
                    ->where('rec_jobs.location_id', '=', $request->location);
            }

            if($request->questions != 'all' && $request->questions != ''){
                $rec_job_questions = config('dbtable.rec_job_questions');
               $r->join(''.$rec_job_questions.'', 'rec_job_questions.job_id', 'rec_job_applications.job_id')
                    ->where('rec_job_questions.question_id', '=', $request->questions);
            }

            if($request->question_value != '' && $request->questions != 'all' && $request->questions != ''){
                 $rec_job_application_answers = config('dbtable.rec_job_application_answers');
                $r->join(''.$rec_job_application_answers.'', 'rec_job_application_answers.job_application_id', 'rec_job_applications.id')
                ->where('rec_job_application_answers.question_id',  $request->questions)
                ->where('rec_job_application_answers.answer', 'LIKE', '%' . $request->question_value . '%');
            }


            // Filter by skills
            if ($request->skill != 'all' && $request->skill != '') {
                foreach (explode(',', $request->skill) as $key => $skill) {
                    if ($key == 0) {
                         $r->whereJsonContains('skills', $skill);
                    }
                    else {
                         $r->orWhereJsonContains('skills', $skill);
                    }
                }
            }


        }, 'applications.schedule']);


          $boardColumns = $boardColumns->orderBy('position')->get()->map(function ($query) {
            $query->setRelation('applications', $query->applications->take(10));
            return $query;
        });

        $currentDate = Carbon::now()->timestamp;
        $locations = JobLocation::all();

        $boardStracture = [];

        foreach ($boardColumns as $key => $column) {
            $boardStracture[$column->id] = [];

            foreach ($column->applications as $application)
            {
                $boardStracture[$column->id][] = $application->id;
            }
        }



         $res=[
            'boardStracture' => json_encode($boardStracture),
            'boardColumns' => $boardColumns,
            'jobs' => $jobs,
            'skills' => $skills,
            'questions' =>$questions,
            'startDate' =>$startDate,
            'endDate' =>$endDate,
            'locations' => $locations,
            'type' => $type,
            'currentDate' => $currentDate
         ];

        return ApiHelper::JSON_RESPONSE(true, $res, ''); 
    }

    public function create()
    {
       
        $jobs = Job::with('location')->get();
        $gender = [
            'male' =>'Male',
            'female' => 'Female',
            'others' => 'Others',
        ];

        $res= [
                'jobs' => $jobs,
                'gender' => $gender
        ];

      return ApiHelper::JSON_RESPONSE(true, $res, ''); 
    }
    

    /**
     * @param $jobID
     * @return mixed
     * @throws \Throwable
     */
    public function jobQuestion(Request $request)
    {        
        $job = Job::findOrFail($request->jobID);
        $applicationId = $request->applicationId;
        $jobID = $request->jobID;
        $jobQuestion = $job->questions()->with([
            'answers' => function ($query) use ($jobID, $applicationId){
                $query->where(['job_application_id' => $applicationId, 'job_id' => $jobID]);
            }
        ])->get(); 

         if ($applicationId) { 

             $application = JobApplication::select('id', 'gender', 'dob', 'country', 'state', 'city')->where('id',
             $applicationId)->first();

         }
  

          $res = [  
            'jobQuestion' => $jobQuestion,
            'job' => $job,
            'application' => $application ?? '',   
        ];
        

          return ApiHelper::JSON_RESPONSE(true, $res,'');
    }


    public function edit(Request $request)
    {

        $statuses = ApplicationStatus::all();
        $application = JobApplication::find($request->id);
        $jobQuestion = $application->job->questions;
        $jobs = Job::select('id', 'title', 'location_id', 'status', 'start_date', 'end_date', 'section_visibility')->with('location:id,location')->get();

        $res = [
            'statuses'=>$statuses, 
            'application' => $application,
            'jobQuestion' => $jobQuestion,
            'jobs' => $jobs, 
            
        ];
        

          return ApiHelper::JSON_RESPONSE(true, $res,'');
    }

    public function data(Request $request)
    { 


        $job_applications = config('dbtable.rec_job_applications');
        $interview_schedule_employees = config('dbtable.rec_interview_schedule_employees');
        $interview_schedules =config('dbtable.rec_interview_schedules');
        $rec_jobs =config('dbtable.rec_jobs');
        $rec_job_application_answers =config('dbtable.rec_job_application_answers');



        $jobApplications = JobApplication::select(''.$job_applications.'.id', ''.$job_applications.'.job_id' , 'status_id', 'full_name', 'skills')
            ->with([
                'job:id,location_id,title',
                'job.skills',
                'job.location:id,location',
                'status:id,status,color',
            ]);
 
        
        // Filter by status
        if ($request->status != 'all' && $request->status != '') {
            $jobApplications = $jobApplications->where('status_id', $request->status);
        }

        // Filter By jobs
        if ($request->jobs != 'all' && $request->jobs != '') {
            $jobApplications = $jobApplications->where('job_id', $request->jobs);
        }

        // Filter By skills
        if ($request->skill != 'all' && $request->skill != '') {
            foreach (explode(',', $request->skill) as $key => $skill) {
                if ($key == 0) {
                    $jobApplications = $jobApplications->whereJsonContains('skills', $skill);
                }
                else {
                    $jobApplications = $jobApplications->orWhereJsonContains('skills', $skill);
                }
            }
        }
        // Filter by location
        if ($request->location != 'all' && $request->location != '') {
            
            $jobApplications = $jobApplications->whereHas('job.location', function ($query) use ($request)
            {
                $query->where('id', $request->location);
            });
        }

        if($request->questions != 'all' && $request->questions != '' && ($request->question_value == '' || is_null($request->question_value))){
            $jobApplications = $jobApplications->whereHas('job.questions', function ($query) use ($request)
            {
                $query->where('question_id', $request->questions);
            });
        }

        if($request->question_value != '' && $request->questions != 'all' && $request->questions != ''){
            $jobApplications = $jobApplications->join(''.$rec_job_application_answers.'', ''.$rec_job_application_answers.'.job_application_id', ''.$job_applications.'.id')
            ->where(''.$rec_job_application_answers.'.question_id',  $request->questions)
            ->where(''.$rec_job_application_answers.'.answer', 'LIKE', '%' . $request->question_value . '%');
        }
        
        // Filter by StartDate
        if ($request->startDate != null && $request->startDate != '') {
            $jobApplications = $jobApplications->whereDate(''.$job_applications.'.created_at', '>=', $request->startDate);
        }


        // Filter by EndDate
        if ($request->endDate != null && $request->endDate != '') {
            $jobApplications = $jobApplications->whereDate(''.$job_applications.'.created_at', '<=', $request->endDate);
        }

        $jobApplications = $jobApplications->get();



        $res = [

                'jobApplications' => $jobApplications, 
            ];



        return ApiHelper::JSON_RESPONSE(true, $res, ''); 
    }


    public function createSchedule(Request $request)
    {
         $api_token = $request->api_token;
        $user_id = ApiHelper::get_user_id_from_token($api_token);

        $candidates = JobApplication::all();
        $users = User::all();
        $zoom_setting = ZoomSetting::first();
        $scheduleDate = $request->date;
        $currentApplicant = JobApplication::findOrFail($request->id);

        $res = [
            'candidates' => $candidates,
            'users' => $users,
            'scheduleDate' => $scheduleDate,
            'currentApplicant' => $currentApplicant,
            'zoom_setting' => $zoom_setting,
            'user' => $user_id
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, ''); 
    }

    public function storeSchedule(StoreRequest $request)
    {
        abort_if(!$this->user->cans('add_schedule'), 403);
        $this->setZoomConfigs();

        $dateTime = $request->scheduleDate . ' ' . $request->scheduleTime;
        $dateTime = Carbon::createFromFormat('Y-m-d H:i', $dateTime);
        if($request->interview_type == 'online'){
            $data = $request->all();
            $meeting = new ZoomMeeting();
            $data['meeting_name'] = $request->meeting_title;
            $data['start_date_time'] = $dateTime;
            $data['end_date_time'] = $request->end_date . ' ' . $request->end_time;
            $meeting = $meeting->create($data);
            $host = User::find($request->create_by);
            $user = Zoom::user()->find('me');
            $meetings = $this->createMeeting($user, $meeting,  null, $host);
         } 
         else{
             $meetings = '';
        } 
        // store Schedule
        $interviewSchedule = new InterviewSchedule();
        $interviewSchedule->interview_type =$request->interview_type;
        $interviewSchedule->meeting_id = ($meetings!= '') ? $meetings->id: null;
        $interviewSchedule->job_application_id = $request->candidates[0];
        $interviewSchedule->schedule_date = $dateTime;
        $interviewSchedule->save();

        // Update Schedule Status
        $status = ApplicationStatus::where('status', 'interview')->first();
        $jobApplication = $interviewSchedule->jobApplication;
        $jobApplication->status_id = $status->id;
        $jobApplication->save();

        if($request->comment){
            $scheduleComment = [
                'interview_schedule_id' => $interviewSchedule->id,
                'user_id' => $this->user->id,
                'comment' => $request->comment
            ];

            $interviewSchedule->comments()->create($scheduleComment);
        }

        if (!empty($request->employees)) {
            $interviewSchedule->employees()->attach($request->employees);

            // Mail to employee for inform interview schedule
            // Notification::send($interviewSchedule->employees, new ScheduleInterview($jobApplication,$meetings));

            $details = [
                'email' => $interviewSchedule->employees,
                'message' => $jobApplication,$meetings,
            ];
            
            ScheduleInterview::dispatch($details);
        }
        if(!$request->interview_type){
            $meeting ='';
        }
        // mail to candidate for inform interview schedule
        Notification::send($jobApplication, new CandidateScheduleInterview($jobApplication, $interviewSchedule,$meetings));

        return Reply::redirect(route('admin.interview-schedule.index'), __('menu.interviewSchedule') . ' ' . __('messages.createdSuccessfully'));
    }

    public function createMeeting($user, ZoomMeeting $meeting, $id, $meetingId = null, $host=null)
    {
        $this->setZoomConfigs();

        // create meeting using zoom API
        $commonSettings = [
            'type' => 2,
            'topic' => $meeting->meeting_name,
            'start_time' => $meeting->start_date_time,
            'duration' => $meeting->end_date_time->diffInMinutes($meeting->start_date_time),
            'timezone' => $this->global->timezone,
            'agenda' => $meeting->description,
            'alternative_host' => [],
            'settings' => [
                'host_video' => $meeting->host_video == 1,
                'participant_video' => $meeting->participant_video == 1,
            ]
        ];

        if($host){
            $commonSettings['alternative_host'] = [$host->email];
        }

        if (is_null($id)) {
            $zoomMeeting = $user->meetings()->make($commonSettings);
            $savedMeeting = $user->meetings()->save($zoomMeeting);

            $meeting->meeting_id = strval($savedMeeting->id);
            $meeting->start_link = $savedMeeting->start_url;
            $meeting->join_link = $savedMeeting->join_url;
            $meeting->password = $savedMeeting->password;

            $meeting->save();
        } else {
            $user->meetings()->find($meeting->meeting_id)->update($commonSettings);
        }

        return $meeting;
    }

    public function store(Request $request)
    {  
         $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        

        $jobApplication = new JobApplication();
        $jobApplication->full_name = $request->full_name;
        $jobApplication->job_id = $request->job_id;
        $jobApplication->status_id = 1; //applied status id
        $jobApplication->email = $request->email;
        $jobApplication->phone = $request->phone;
        $jobApplication->address = $request->address;
        $jobApplication->cover_letter = $request->cover_letter;
        $jobApplication->column_priority = 0;

        if ($request->has('gender')) {
            $jobApplication->gender = $request->gender;
        }
        if ($request->has('dob')) {
            $jobApplication->dob = $request->dob;
        }
        if ($request->has('country')) {

            if(!empty($request->country)){
                $countriesArray = json_decode(file_get_contents(public_path('country-state-city/countries.json')), true)['countries'];
                $jobApplication->country = $this->getName($countriesArray, $request->country);
            }
            
            if(!empty($request->state)){
                $statesArray = json_decode(file_get_contents(public_path('country-state-city/states.json')), true)['states'];
                $jobApplication->state = $this->getName($statesArray, $request->state);
            }

           
            $jobApplication->city = $request->city;
            $jobApplication->zip_code = $request->zip_code;
        }

        
        if ($request->hasFile('photo')) {
            $image=$request->file('photo');
            $extension=$image->extension();
            $fileN=time();
            $fileName = $fileN.'.'.$extension;
            $path = $image->move(public_path('/recruit/profile'), $fileName);

            $jobApplication->photo = $fileName;
            
        };
 
        $jobApplication->save();

        if ($request->hasFile('resume')) {
                $image=$request->file('resume');
                $extension=$image->extension();
                $fileN=time();
                $fileName = $fileN.'.'.$extension;
                $path = $image->move(public_path('/recruit/resume'), $fileName);


                $jobApplication->documents()->create([
                'name' => 'Resume',
                'hashname' => $fileName
            ]);
        }

        // Job Application Answer save
        if (isset($request->answer) && !empty($request->answer)) {
            foreach ($request->answer as $key => $value) {
                $answer = new JobApplicationAnswer();
                $answer->job_application_id = $jobApplication->id;
                $answer->job_id = $request->job_id;
                $answer->question_id = $key;
                if($request->hasFile('answer.' . $key)){
                    $answer->file = Files::uploadLocalOrS3($value,'documents');
                }else{
                    $answer->answer = $value;
                }
                $answer->save();
            }
        } 

       return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_ADD_JOB_APPLICATION'); 
    }

    public function update(Request $request)
    { 


        $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');


        
    
        $id = $request->id;

        $jobApplication = JobApplication::findOrFail($id);
        $jobApplication->full_name = $request->full_name;
        $jobApplication->job_id = $request->job_id;
        $jobApplication->status_id = $request->status_id;
        $jobApplication->email = $request->email;
        $jobApplication->phone = $request->phone;
        $jobApplication->address = $request->address;
        $jobApplication->cover_letter = $request->cover_letter;

        if ($request->has('gender')) {
            $jobApplication->gender = $request->gender;
        }
        if ($request->has('dob')) {
            $jobApplication->dob = $request->dob;
        }
        if ($request->has('country')) {

            if(!empty($request->country)){
                $countriesArray = json_decode(file_get_contents(public_path('country-state-city/countries.json')), true)['countries'];
                $jobApplication->country = $this->getName($countriesArray, $request->country);
            }
            
            if(!empty($request->state)){
                $statesArray = json_decode(file_get_contents(public_path('country-state-city/states.json')), true)['states'];
                $jobApplication->state = $this->getName($statesArray, $request->state);
            }

            
           
            $jobApplication->city = $request->city;
            $jobApplication->zip_code = $request->zip_code;
        }
 
        $isStatusDirty = $jobApplication->isDirty('status_id');



         if ($request->file('photo')) {
            $image=$request->file('photo');
            $extension=$image->extension();
            $fileN=time();
            $fileName = $fileN.'.'.$extension;
            $path = $image->move(public_path('/recruit/profile'), $fileName);

             $jobApplication->photo = $fileName;  
            
        };
 
        
        $jobApplication->save();


        if ($request->hasFile('resume')) {
 
            $dir = trim('recruit/resume/'.$jobApplication->id , '/');
            $path = $dir . '/' . $jobApplication->resumeDocument->hashname;
            if (!\File::exists(public_path($path))) {
                \Storage::delete($path);
            }


            $image=$request->file('resume');
            $extension=$image->extension();
            $fileN=time();
            $fileName = $fileN.'.'.$extension;
            $path = $image->move(public_path('/recruit/resume'), $fileName);


            $jobApplication->documents()->updateOrCreate([
                'documentable_type' => JobApplication::class,
                'documentable_id' => $jobApplication->id,
                'name' => 'Resume'
            ],
            [
                'hashname' => $fileName
            ]);


        }

        // Job Application Answer save
        if (isset($request->answer) && count($request->answer) > 0) {
            foreach ($request->answer as $key => $value) {
                if($request->hasFile('answer.' . $key)){
                    $file = Files::upload($value,'documents');
                    
                }else{
                    $answer = $value;
                }
                JobApplicationAnswer::updateOrCreate([
                    'job_application_id' => $jobApplication->id,
                    'job_id' => $jobApplication->job_id,
                    'question_id' => $key
                ], ['answer' => !empty($answer) ? $answer : null , 'file' => !empty($file) ? $file : null ]);
                $answer = '';
            }
            }
        

         return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_UPDATE_JOB_APPLICATION'); 
    }

    public function destroy(Request $request)
    {
        $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageremove))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');
    
        $data = JobApplication::findOrFail($request->id);

        if ($data->photo) {
            Storage::delete('candidate-photos/'.$data->photo);
        }

        $data->forceDelete();


        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_DELETE_JOBAPPLICATION'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_JOBAPPLICATION_DELETE');
        }


    }

    public function show(Request $request)
    {
        $id = $request->id;
        $application = JobApplication::with(['schedule','notes','onboard', 'status', 'schedule.employee', 'schedule.comments.user'])->find($id);
        $skills = Skill::select('id', 'name')->get();
        $zoom_setting = ZoomSetting::first();
        $answers = JobApplicationAnswer::with(['question'])
            ->where('job_id', $application->job_id)
            ->where('job_application_id', $application->id)
            ->get();


        $res = [
            "application" => $application,
            "skills" => $skills,
            "answers" => $answers,
            'status' => 'success',
            'zoom_setting' => $zoom_setting
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, 'SUCCESS'); 
    }

    public function updateIndex(Request $request)
    {
        $taskIds = $request->applicationIds; 
        $boardColumnIds = $request->boardColumnIds;
        $priorities = $request->prioritys;
      

        $date = Carbon::now();
        $startDate = $request->startDate ?: $date->subDays(30)->format('Y-m-d');
        $endDate = $request->endDate ?: $date->format('Y-m-d');
        
        if ($request->has('applicationIds')) {
            foreach ($taskIds as $key => $taskId) {
                if (!is_null($taskId)) {

                    $task = JobApplication::find($taskId);
                    $task->column_priority = $priorities[$key];
                    $task->status_id = $boardColumnIds[$key];

                    $task->save();
                }
            }

      
        }

        $columnCountByIds = ApplicationStatus::select('id', 'color')
            ->withCount([
                'applications as status_count' => function ($query) use($startDate, $endDate, $request) {
                    $query->withoutTrashed()->whereDate('created_at', '>=', $startDate)->whereDate('created_at', '<=', $endDate);
                    if ($request->jobs != 'all' && $request->jobs != '') {
                        $query->where('job_id', $request->jobs);
                    }
                    if ($request->search != '') {
                        $query->where('full_name', 'LIKE', '%' . $request->search . '%');
                    }
                }
            ])
            ->get()
            ->toArray();


        $res = [
            "columnCountByIds" => $columnCountByIds,
            'status' => 'success',
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, 'SUCCESS'); 
    }

    public function table()
    {

        $boardColumns = ApplicationStatus::all();
        $locations = JobLocation::all();
        $jobs = Job::with('location')->get();
        $skills = Skill::all();
        $questions = Question::all();
        $JobApplication = JobApplication::with('job','status')->get();

        $res = [
            'boardColumns'=>$boardColumns,
            'locations'=>$locations,
            'jobs'=>$jobs,
            'skills'=>$skills,
            'questions'=>$questions,
            'JobApplications'=>$JobApplication,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, ''); 
    }

    public function ratingSave(Request $request, $id)
    {
       

        $application = JobApplication::withTrashed()->findOrFail($id);
        $application->rating = $request->rating;
        $application->save();

        return Reply::success(__('messages.updatedSuccessfully'));
    }

    // Job Applications data Export
    public function export(Request $request)
    {
        $filters = [
            'status' => $request->status,
            'location' => $request->location,
            'startDate' => $request->startDate,
            'endDate' => $request->endDate,
            'jobs' => $request->jobs,
        ];

        $data = [
            'company' => ''
        ];

        // return Excel::download(new JobApplicationExport($filters, $data), 'job-applications.xlsx', ExcelExcel::XLSX);

        // $data = Excel::store(new JobApplicationExport($filters), 'job-applications.xlsx', ExcelExcel::XLSX);

        $data = Excel::store(new JobApplicationExport($filters), 'job-applications.xlsx');

        $url = Storage::path('job-applications.xlsx');

        return ApiHelper::JSON_RESPONSE(true,$url,'');

    }

     public function getName($arr, $id)
    {
        $result = array_filter($arr, function ($value) use ($id) {
            return $value['id'] == $id;
        });
        return current($result)['name'];
    }

    public function archiveJobApplication(Request $request)
    {

        $application = JobApplication::find($request->id);
        $application->delete();

        return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS');
    }

    public function unarchiveJobApplication(Request $request)
    {
        

        $application = JobApplication::select('id', 'deleted_at')->withTrashed()->where('id', $request->application_id)->first();
        
        $application->restore();

         $res = [
                "application" => $application, 
            ];


        return ApiHelper::JSON_RESPONSE(true, $res, 'APPLICATION_UNARCHIVED_SUCCESSFULLY.'); 
            
    }

    public function addSkills(Request $request)
    { 

        $application = JobApplication::withTrashed()->findOrFail($request->applicationId);
        $application->skills = $request->skills;
        $application->save();

        return ApiHelper::JSON_RESPONSE(true, [], 'SKILL_SAVED_SUCCESSFULLY.'); 
    }

    public function loadMore(Request $request)
    {

        $startDate = ($request->startDate != 'null') ? Carbon::parse( $request->startDate)->toDateString() : null;
        $endDate = ($request->endDate != 'null') ? Carbon::parse($request->endDate)->toDateString() : null;
        $skip = $request->currentTotalRecords;
        // dd($skip);
        

        $totalRecord = $request->totalRecord;

        $this->currentDate = Carbon::now()->timestamp;

        $applications = JobApplication::with('status')->select('job_applications.*')
        ->where('status_id', $request->columnId);
        
        
        if ($startDate !== null && $request->startDate != 'null' && $request->startDate != '') {
            $applications = $applications->where(DB::raw('DATE(job_applications.`created_at`)'), '>=', $startDate);
        } else {
        }
        

        if ($endDate !== null && $request->endDate != 'null' && $request->endDate != '') {
            $applications = $applications->where(DB::raw('DATE(job_applications.`created_at`)'), '<=', $endDate);
        } else {
        }
       
        // Filter By jobs
        if ($request->jobs != 'all' && $request->jobs != '') {
            $applications = $applications->where('job_applications.job_id', $request->jobs);
        }
        
        // Filter by EndDate
        if ($request->search != null && $request->search != '') {
            $applications = $applications->where('full_name', 'LIKE', '%' . $request->search . '%')
                    ->orWhere('email', 'LIKE', '%' . $request->search . '%')
                    ->orWhere('phone', 'LIKE', '%' . $request->search . '%');
                   
        }

        // Filter  by Location
        if ($request->location != 'all' && $request->location != '')
        {
            $applications->leftJoin('jobs', 'jobs.id', 'job_applications.job_id')
                ->where('jobs.location_id', '=', $request->location);
        }

        if($request->questions != 'all' && $request->questions != ''){

           $applications->join('job_questions', 'job_questions.job_id', 'job_applications.job_id')
                ->where('job_questions.question_id', '=', $request->questions);
        }

        if($request->question_value != '' && $request->questions != 'all' && $request->questions != ''){
            
            $applications->join('job_application_answers', 'job_application_answers.job_application_id', 'job_applications.id')
            ->where('job_application_answers.question_id',  $request->questions)
            ->where('job_application_answers.answer', 'LIKE', '%' . $request->question_value . '%');
        }

        // Filter by skills
        if ($request->skill != 'all' && $request->skill != '') {
            foreach (explode(',', $request->skill) as $key => $skill) {
                if ($key == 0) {
                     $applications->whereJsonContains('skills', $skill);
                }
                else {
                     $applications->orWhereJsonContains('skills', $skill);
                }
            }
        }

        $applications->orderBy('column_priority')->skip($skip)->take($this->perPage);
        $applications = $applications->get();


        
        $this->applications = $applications;

        if ($totalRecord <= ($skip + $this->perPage)) {
            $loadStatus = 'hide';
        }
        else {
            $loadStatus = 'show';
        }

        $view = view('admin.job-applications.load_more', $this->data)->render();

        return Reply::dataOnly(['view' => $view, 'load_more' => $loadStatus]);
    }

    
}
