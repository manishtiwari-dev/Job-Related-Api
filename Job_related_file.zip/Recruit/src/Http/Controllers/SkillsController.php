<?php

namespace Modules\Recruit\Http\Controllers;


use App\Helper\Reply; 
use Modules\Recruit\Models\JobCategory;
use Modules\Recruit\Models\Skill;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;
use ApiHelper;
use Illuminate\Support\Facades\Validator;

class SkillsController extends Controller
{

        
    public $page = 'skills';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pageremove = 'remove';
    public $pageupdate = 'update';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');


        $skills = Skill::with('category')->get();

        /*Binding data into a variable*/

        $res = [
            'skills' => $skills,

        ];


        return ApiHelper::JSON_RESPONSE(true, $res, ''); 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    { 

        $job_category = JobCategory::all();


         $res = [
            'job_category' => $job_category,

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, ''); 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    { 

          $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        $validator = Validator::make(
            $request->all(),
            [
                'category_id' => 'required',
            ],
            [

                'category_id.required' => 'JOB_CATEGORY_FIELD_REQUIRED',

            ]

        );


        if ($validator->fails()) {
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
        }


        $names = $request->name;
        $categoryId = $request->category_id;

        if (trim($names[0]) == '') {
            return ApiHelper::JSON_RESPONSE(false, [], 'Skill Name Can Not Be Blank');
        }

        
        foreach ($names as $name):
            if(!is_null($name)){
                $data = Skill::create(['name' => $name, 'category_id' => $categoryId]);
            }
        endforeach;

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_ADD_SKILLS'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_SKILLS_ADD');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {


        $id = $request->id;
        $categories = JobCategory::all();
        $skill = Skill::find($id);


        $api_token = $request->api_token;

        $skill = Skill::find($id);

        $res = [
            'skill'=>$skill, 
            'categories' => $categories
            
        ];
        

          return ApiHelper::JSON_RESPONSE(true, $res,'');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {

        $api_token = $request->api_token;
      

        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        
        $api_token = $request->api_token;
        $id = $request->id;

       $validator = Validator::make(
            $request->all(),
            [
                'name' => 'required',
                'category_id' => 'required',
            ],
            [

                'name.required' => 'NAME_FIELD_REQUIRED',
                'category_id.required' => 'CATEGORY_NAME_IS_REQUIRED',

            ]

        );

        if ($validator->fails()) {
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
        }



        $data = Skill::find($request->id);
        $data->name = $request->name;
        $data->category_id = $request->category_id;
        $data->save();


        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_UPDATE_SKILLS'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_SKILLS_UPDATE');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    { 
         $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageremove))
        return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');
    

        $data =Skill::destroy($request->id); 

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_DELETE_SKILLS'); 
        }else{
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_SKILLS_DELETE');
        }
    }


}
