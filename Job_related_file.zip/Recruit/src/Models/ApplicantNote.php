<?php

namespace Modules\Recruit\Models;

use Illuminate\Database\Eloquent\Model;
use app\Models\User;

class ApplicantNote extends Model
{

	 public function getTable()
    {
        return config('dbtable.rec_applicant_notes');
    }

    
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
