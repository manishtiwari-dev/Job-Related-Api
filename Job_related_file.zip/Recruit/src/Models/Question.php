<?php


namespace Modules\Recruit\Models;

use Illuminate\Database\Eloquent\Model;

class Question extends Model
{
    protected $guarded = ['id'];

      public function getTable()
    {
        return config('dbtable.rec_questions');
    }

    public function jobs()
    {
        $this->belongsToMany(Job::class, config('dbtable.rec_job_questions'));
    }

    public function answers()
    {
        return $this->hasMany(JobApplicationAnswer::class);
    }

   
}
