<?php

namespace Modules\Recruit\Models;

use Illuminate\Database\Eloquent\Model;

class JobAlertLocation extends Model
{
    //
    

 public function getTable()
    {
        return config('dbtable.rec_job_alert_locations');
    }

    public function location()
    {   
        return $this->belongsTo(JobLocation::class, 'location_id');
    }
}
