<?php

namespace Modules\Recruit\Models;

use Carbon\Carbon;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\Model;
use Modules\HRM\Models\Staff;
use App\Models\Currency; 

class Onboard extends Model
{

    public function getTable()
    {
        return config('dbtable.rec_on_board_details');
    }
    protected $dates = ['joining_date', 'accept_last_date'];

    public function files()
    {
        return $this->hasMany(OnboardFiles::class, 'on_board_detail_id');
    }

    public function applications()
    {
        return $this->belongsTo(JobApplication::class, 'job_application_id');
    }

    public function department(){
        return $this->belongsTo(Department::class);
    }

    public function designation(){
        return $this->belongsTo(Designation::class);
    }

    public function reportto(){ 
         return $this->belongsTo(Staff::class, 'reports_to_id', 'staff_id');
    }
    public function getExt($name){

    }

    public function  currency(){
         return $this->belongsTo(Currency::class, 'currencies_id');
    }

     public function onboardQuestion(){
        return $this->belongsToMany(JobOfferQuestion::class, config('dbtable.rec_job_onboard_questions'), 'job_offer_id', 'question_id');
    }
}
