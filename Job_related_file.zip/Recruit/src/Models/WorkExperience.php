<?php

namespace Modules\Recruit\Models;

use Illuminate\Database\Eloquent\Model;

class WorkExperience extends Model
{
     public function getTable()
    {
        return config('dbtable.rec_work_experiences');
    }
}
