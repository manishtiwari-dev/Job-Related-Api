<?php
 
namespace Modules\Recruit\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use App\Models\User;

class InterviewScheduleEmployee extends Model
{
    use Notifiable;

    public function schedule(){
        return $this->belongsTo(InterviewSchedule::class, 'interview_schedule_id');
    }

    public function user(){
        return $this->belongsTo(User::class, 'user_id');
    }

     public function getTable()
    {
        return config('dbtable.rec_interview_schedule_employees');
    }


    


}
