<?php

namespace Modules\Recruit\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Country;

class JobLocation extends Model
{
    protected $guarded = ['id'];
 
    public function getTable()
    {
        return config('dbtable.rec_job_locations');
    }


    public function country(){
        return $this->belongsTo(Country::class, 'country_id');
    }
}
