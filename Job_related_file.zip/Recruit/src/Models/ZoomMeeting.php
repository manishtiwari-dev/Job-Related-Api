<?php

namespace Modules\Recruit\Models;

use Illuminate\Database\Eloquent\Model;

class ZoomMeeting extends Model
{ 


    public function getTable()
    {
        return config('dbtable.rec_zoom_meetings');
    }
 
    protected $guarded = ['id'];

    protected $dates = ['start_date_time', 'end_date_time'];

    protected static function boot()
    {
        parent::boot();
    }

    public function attendees()
    {
        return $this->belongsToMany(User::class );
    }

    public function host()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function category()
    {
        return $this->belongsTo(Category::class, 'category_id');

    }
}
