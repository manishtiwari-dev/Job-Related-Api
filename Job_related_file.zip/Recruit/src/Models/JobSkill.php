<?php

namespace Modules\Recruit\Models;

use Illuminate\Database\Eloquent\Model;

class JobSkill extends Model
{

	public function getTable()
    {
        return config('dbtable.rec_job_skills');
    }
    
    public function skill(){
        return $this->belongsTo(Skill::class, 'skill_id');
    }
}
