<?php

namespace Modules\Recruit\Models\Notifications;

use Modules\Recruit\Models\JobApplication;
use Modules\Recruit\Traits\SmtpSettings;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Messages\NexmoMessage;

class ScheduleInterview extends Notification
{
    use Queueable, SmtpSettings;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct(JobApplication $jobApplication , $meetings)
    {
        $this->jobApplication = $jobApplication;
        $this->meetings = $meetings;

        $this->setMailConfigs();
        // $this->setSmsConfigs();
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        $via = ['mail', 'database'];

        if ( $notifiable->mobile_verified == 1) {
            array_push($via, 'nexmo');   
        }

        return $via;
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        $emailContent = (new MailMessage)
            ->subject('Interview scheduled')
            ->greeting('Hello'.' ' . ucwords($notifiable->name) . '!')
            ->line(__($this->jobApplication->full_name).' '.'interview scheduled for job'.' - ' . ucwords($this->jobApplication->job->title))
            ->action('For accept or refuse'.' '.'Login to Dashboard', url('/login'));
           
            $emailContent =  $emailContent->line('Interview Type'.' - ' . 'Offline');

           
            $emailContent = $emailContent->line('Thank You!');
            return $emailContent;
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'data' => $this->jobApplication->toArray()
        ];
    }

    /**
     * Get the Nexmo / SMS representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return NexmoMessage
     */
    public function toNexmo($notifiable)
    {
        return (new NexmoMessage)
                    ->content(
                        __($this->jobApplication->full_name).' '.__('email.interviewSchedule.text').' - ' . ucwords($this->jobApplication->job->title)
                    )->unicode();
    }
}
