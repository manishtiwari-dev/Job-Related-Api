<?php

namespace Modules\Recruit\Models;

use Illuminate\Database\Eloquent\Model;

class JobOnboardQuestion extends Model
{
    //
}
