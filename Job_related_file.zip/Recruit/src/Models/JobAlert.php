<?php

namespace Modules\Recruit\Models;
use Modules\Recruit\Models\JobType;
use Modules\Recruit\Models\JobCategory;
use Modules\Recruit\Models\JobLocation;
use Modules\Recruit\Models\WorkExperience;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class JobAlert extends Model
{
    use Notifiable;
    
    protected $guarded = ['id'];



    public function getTable()
    {
        return config('dbtable.rec_job_alerts');
    }


    public function workExperience()
    {
        return $this->belongsTo(WorkExperience::class, 'work_experience_id');
    }

    public function  jobType()
    {
        return $this->belongsTo(JobType::class, 'job_type_id');
    }

    public function alertCategory()
    {
        return $this->belongsToMany(JobCategory::class, 'job_alert_categories', 'job_alert_id', 'category_id');
    }

    public function alertLocation()
    {
        return $this->belongsToMany(JobLocation::class, 'job_alert_locations', 'job_alert_id', 'location_id');
    }

    public function alertLocationData(){
        return $this->belongsToMany(JobLocation::class)->withPivot('job_alert_id', 'job_location_id');
    }

    

}
