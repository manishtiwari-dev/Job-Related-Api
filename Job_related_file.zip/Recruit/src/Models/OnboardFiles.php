<?php

namespace Modules\Recruit\Models;
use Illuminate\Database\Eloquent\Model;

class OnboardFiles extends Model
{
    public function getTable()
    {
        return config('dbtable.rec_on_board_files');
    }
}
