<?php

namespace Modules\Recruit\Models;
use Illuminate\Database\Eloquent\Model;

class JobOfferQuestion extends Model
{
    public function getTable()
    {
        return config('dbtable.rec_job_offer_questions');
    }
}
