<?php


namespace Modules\Recruit\Models;

use Illuminate\Database\Eloquent\Model;

class Document extends Model
{
    protected $guarded = ['id'];

    public function documentable()
    {
        return $this->morphTo();
    }

    public function getTable()
    {
        return config('dbtable.rec_documents');
    }
}