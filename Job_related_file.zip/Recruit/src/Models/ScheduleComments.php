<?php

namespace Modules\Recruit\Models;

use Illuminate\Database\Eloquent\Model;
use app\Models\User;

class ScheduleComments extends Model
{
    protected $guarded = ['id'];
    
    protected $dates = ['created_at'];
    
    public function getTable()
    {
        return config('dbtable.rec_interview_schedule_comments');
    }

    // Relation with job application
    public function jobApplication(){
        return $this->belongsTo(InterviewSchedule::class);
    }

    // Relation with user
    public function user(){
        return $this->belongsTo(User::class);
    }


}