<?php

namespace Modules\Recruit\Models;

use Illuminate\Database\Eloquent\Model;

class JobType extends Model
{
     public function getTable()
    {
        return config('dbtable.rec_job_types');
    }
}
