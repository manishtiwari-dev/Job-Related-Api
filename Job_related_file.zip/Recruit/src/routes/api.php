<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Modules\Recruit\Http\Controllers\JobsController;
use Modules\Recruit\Http\Controllers\LocationsController;
use Modules\Recruit\Http\Controllers\SkillsController;
use Modules\Recruit\Http\Controllers\JobCategoryController;
use Modules\Recruit\Http\Controllers\JobOnboardController;
use Modules\Recruit\Http\Controllers\JobTypeController;
use Modules\Recruit\Http\Controllers\WorkExperienceController;
use Modules\Recruit\Http\Controllers\QuestionController;
use Modules\Recruit\Http\Controllers\InterviewScheduleController;
use Modules\Recruit\Http\Controllers\JobApplicationController;
use Modules\Recruit\Http\Controllers\ApplicationArchiveController;
use Modules\Recruit\Http\Controllers\DocumentController;
use Modules\Recruit\Http\Controllers\ApplicationSettingsController;
use Modules\Recruit\Http\Controllers\ApplicationStatusController;
use Modules\Recruit\Http\Controllers\SettingController;
use Modules\Recruit\Http\Controllers\FrontJobsController;
use Modules\Recruit\Http\Controllers\ReportController;
use Modules\Recruit\Http\Controllers\ApplicantNoteController;




/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/



Route::group(['middleware' => ['ApiTokenCheck'],'prefix'=>"api/"], function() {


    Route::group(['prefix'=>'jobs'], function(){
        Route::post('/', [JobsController::class,'index']);
        Route::post('/create', [JobsController::class, 'create']);
        Route::post('/store', [JobsController::class, 'store']);
        Route::post('/edit', [JobsController::class, 'edit']);
        Route::post('/update', [JobsController::class, 'update']);
        Route::post('/destroy', [JobsController::class, 'destroy']);
        Route::post('/data', [JobsController::class, 'data']);
        Route::post('/send-email', [JobsController::class, 'sendEmail']);
        Route::post('/filter-job-applications', [JobsController::class, 'filterJobApplications']); 
        
        Route::post('/sendEmails', [JobsController::class, 'sendEmails']); 



    });



    Route::group(['prefix'=>'joblocation'], function(){
        Route::post('/', [LocationsController::class,'index']);
        Route::post('/create', [LocationsController::class, 'create']);
        Route::post('/store', [LocationsController::class, 'store']);
        Route::post('/edit', [LocationsController::class, 'edit']);
        Route::post('/update', [LocationsController::class, 'update']);
        Route::post('/destroy', [LocationsController::class, 'destroy']);
    });



    Route::group(['prefix'=>'skills'], function(){
        Route::post('/', [SkillsController::class,'index']);
        Route::post('/create', [SkillsController::class, 'create']);
        Route::post('/store', [SkillsController::class, 'store']);
        Route::post('/edit', [SkillsController::class, 'edit']);
        Route::post('/update', [SkillsController::class, 'update']);
        Route::post('/destroy', [SkillsController::class, 'destroy']);
    });


    Route::group(['prefix'=>'job-categories'], function(){
        Route::post('/', [JobCategoryController::class,'index']);
        Route::post('/create', [JobCategoryController::class, 'create']);
        Route::post('/store', [JobCategoryController::class, 'store']);
        Route::post('/edit', [JobCategoryController::class, 'edit']);
        Route::post('/update', [JobCategoryController::class, 'update']);
        Route::post('/destroy', [JobCategoryController::class, 'destroy']);
        Route::post('/getSkills', [JobCategoryController::class, 'getSkills']);
    });


    Route::group(['prefix'=>'job-onboard'], function(){
        Route::post('/', [JobOnboardController::class,'index']);
        Route::post('/create', [JobOnboardController::class, 'create']);
        Route::post('/store', [JobOnboardController::class, 'store']);
        Route::post('/edit', [JobOnboardController::class, 'edit']);
        Route::post('/update', [JobOnboardController::class, 'update']);
        Route::post('/destroy', [JobOnboardController::class, 'destroy']);
        Route::post('/data', [JobOnboardController::class, 'data']);
        Route::post('/show', [JobOnboardController::class, 'show']);
        Route::post('/send-offer', [JobOnboardController::class, 'sendOffer']);
        Route::post('/update-status', [JobOnboardController::class, 'updateStatus']);

        

    });


     Route::group(['prefix'=>'job-type'], function(){
        Route::post('/create', [JobTypeController::class, 'create']);
        Route::post('/store', [JobTypeController::class, 'store']);
        Route::post('/update', [JobTypeController::class, 'update']);
        Route::post('/destroy', [JobTypeController::class, 'destroy']);
    });


     Route::group(['prefix'=>'work-experience'], function(){
        Route::post('/create', [WorkExperienceController::class, 'create']);
        Route::post('/store', [WorkExperienceController::class, 'store']);
        Route::post('/update', [WorkExperienceController::class, 'update']);
        Route::post('/destroy', [WorkExperienceController::class, 'destroy']);
    });


      Route::group(['prefix'=>'questions'], function(){
        Route::post('/', [QuestionController::class,'index']);
        Route::post('/create', [QuestionController::class, 'create']);
        Route::post('/store', [QuestionController::class, 'store']);
        Route::post('/edit', [QuestionController::class, 'edit']);
        Route::post('/update', [QuestionController::class, 'update']);
        Route::post('/destroy', [QuestionController::class, 'destroy']);
    });


      Route::group(['prefix'=>'interview-schedule'], function(){
        Route::post('/', [InterviewScheduleController::class,'index']);
        Route::post('/create', [InterviewScheduleController::class, 'create']);
        Route::post('/store', [InterviewScheduleController::class, 'store']);
        Route::post('/edit', [InterviewScheduleController::class, 'edit']);
        Route::post('/update', [InterviewScheduleController::class, 'update']);
        Route::post('/destroy', [InterviewScheduleController::class, 'destroy']);
        Route::post('/table', [InterviewScheduleController::class, 'table']);
        Route::post('/show', [InterviewScheduleController::class, 'show']);
        Route::post('/data', [InterviewScheduleController::class, 'data']);
        Route::post('/changeStatusMultiple', [InterviewScheduleController::class, 'changeStatusMultiple']);
    });


    Route::group(['prefix'=>'job-application'], function(){
        Route::post('/', [JobApplicationController::class,'index']);
        Route::post('/create', [JobApplicationController::class, 'create']);
        Route::post('/store', [JobApplicationController::class, 'store']);
        Route::post('/edit', [JobApplicationController::class, 'edit']);
        Route::post('/update', [JobApplicationController::class, 'update']);
        Route::post('/destroy', [JobApplicationController::class, 'destroy']);
        Route::post('/table', [JobApplicationController::class, 'table']);
        Route::post('/data', [JobApplicationController::class, 'data']);
        Route::post('/export', [JobApplicationController::class, 'export']);
        Route::post('/show', [JobApplicationController::class, 'show']);
        Route::post('/updateIndex', [JobApplicationController::class, 'updateIndex']);
        Route::post('/archive-job-application', [JobApplicationController::class, 'archiveJobApplication']);
        Route::post('/jobQuestion', [JobApplicationController::class, 'jobQuestion']);
        
        Route::post('/createSchedule', [JobApplicationController::class, 'createSchedule']);
        Route::post('/unarchiveJob', [JobApplicationController::class, 'unarchiveJobApplication']);

         Route::post('/addskill', [JobApplicationController::class, 'addSkills']);


        
    });


    Route::group(['prefix'=>'candidate-database'], function(){
        Route::post('/', [ApplicationArchiveController::class,'index']);
        Route::post('/create', [ApplicationArchiveController::class, 'create']);
        Route::post('/store', [ApplicationArchiveController::class, 'store']);
        Route::post('/edit', [ApplicationArchiveController::class, 'edit']);
        Route::post('/update', [ApplicationArchiveController::class, 'update']);
        Route::post('/show', [ApplicationArchiveController::class, 'show']);
        Route::post('/destroy', [ApplicationArchiveController::class, 'destroy']);
        Route::post('/data', [ApplicationArchiveController::class, 'data']);
        Route::post('/export', [ApplicationArchiveController::class, 'export']);
        Route::post('/delete-record', [ApplicationArchiveController::class, 'deleteRecords']);


    });


     Route::group(['prefix'=>'documents'], function(){
        Route::post('/', [DocumentController::class,'index']);
        Route::post('/create', [DocumentController::class, 'create']);
        Route::post('/store', [DocumentController::class, 'store']);
        Route::post('/edit', [DocumentController::class, 'edit']);
        Route::post('/update', [DocumentController::class, 'update']);
        Route::post('/destroy', [DocumentController::class, 'destroy']);
    });

     Route::group(['prefix'=>'application-setting'], function(){
        Route::post('/', [ApplicationSettingsController::class,'index']);
        Route::post('/create', [ApplicationSettingsController::class, 'create']);
        Route::post('/store', [ApplicationSettingsController::class, 'store']);
        Route::post('/edit', [ApplicationSettingsController::class, 'edit']);
        Route::post('/update', [ApplicationSettingsController::class, 'update']);
        Route::post('/destroy', [ApplicationSettingsController::class, 'destroy']);
    });

      Route::group(['prefix'=>'application-status'], function(){
        Route::post('/', [ApplicationStatusController::class,'index']);
        Route::post('/create', [ApplicationStatusController::class, 'create']);
        Route::post('/store', [ApplicationStatusController::class, 'store']);
        Route::post('/edit', [ApplicationStatusController::class, 'edit']);
        Route::post('/update', [ApplicationStatusController::class, 'update']);
        Route::post('/destroy', [ApplicationStatusController::class, 'destroy']);
    });


    Route::group(['prefix'=>'setting'], function(){
        Route::post('/', [SettingController::class,'index']);
        Route::post('/create', [SettingController::class, 'create']);
        Route::post('/store', [SettingController::class, 'store']);
        Route::post('/edit', [SettingController::class, 'edit']);
        Route::post('/update', [SettingController::class, 'update']);
        Route::post('/destroy', [SettingController::class, 'destroy']);
    });
    
    
    Route::group(['prefix'=>'front-job'], function(){
        Route::post('/jobDetail', [FrontJobsController::class,'jobDetail']); 
    });

    Route::group(['prefix'=>'reports'], function(){
        Route::post('/', [ReportController::class,'index']); 
    });


    Route::group(['prefix'=>'application-note'], function(){
        Route::post('/store', [ApplicantNoteController::class,'store']); 
        Route::post('/update', [ApplicantNoteController::class,'update']); 
        Route::post('/destroy', [ApplicantNoteController::class,'destroy']); 
    });


    
    

});

