<?php
/**
 * Created by PhpStorm.
 * User: DEXTER
 * Date: 24/05/17
 * Time: 11:29 PM
 */

namespace Modules\Recruit\Traits;

use App\CompanySetting;
use App\EmailSetting;
use Illuminate\Mail\MailServiceProvider;
use Illuminate\Support\Facades\Config;

trait SmtpSettings
{

    public function setMailConfigs()
    { 
        
        // Ignore incase of development
        if (\config('app.env') !== 'development') {
            Config::set('mail.driver', 'smtp');
            Config::set('mail.host', 'sandbox.smtp.mailtrap.io');
            Config::set('mail.port', 2525);
            Config::set('mail.username', '85ea553af6f162');
            Config::set('mail.password', 'd52e20dc1a24a0');
            Config::set('mail.encryption', 'tls');
        }
        (new MailServiceProvider(app()))->register();
    }

}